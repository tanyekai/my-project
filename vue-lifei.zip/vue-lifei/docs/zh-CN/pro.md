---
nav: zh-CN
---

<p class="tip">
  你可以以公司的名义进行赞助，告知我公司名字、链接和 logo，将展示在侧边栏或者首页。
  <br>联系方式: `i@mao.li`
</p>

## 捐赠

<p class="tip">
10.24买不了一杯咖啡，也不能使作者变得富有，但代表了对项目的赞赏和对作者的鼓励。</p>

<p align="center">
  <img src="https://o3e85j0cv.qnssl.com/static/wechat_pay_10_24.jpg?821d3eb" width="450">
</p>

## Pro

<p align="center">
  <img src="https://cloud.githubusercontent.com/assets/559179/21577536/0a982afa-cf99-11e6-9426-0d23b5755e12.png" width="300">
</p>

2017 希望整个项目有新的发展，也希望能及时快速解决大家的问题，但是同样考虑到成本问题，决定<del>先圈点钱</del>开个付费圈。**即使你不付费加入你在 Github 上提的 issue 依然会被逐一解决**。有兴趣的同学可以加入，希望不只是 Vux, Vue，web 相关的问题都可以讨论交流吐槽求建议。春节前后(Vux2.x 反馈的bug已经大部分清除)会正式维护这个圈。

如果是原 Bearychat 付费用户请联系我(i@mao.li)使用邀请直接加入。

**另外为 Vux 项目做出重要PR的同学将会得到红包奖励、使用 Vux 开发的项目作为 show case 将会得红包**。

<p class="tip">购买鄙司<a href="#" router-link="/zh-CN/livingearth?x-page=pro">产品</a> >= ￥64 可以直接加入圈子。</p>

## 微信

如果你有不明白的非代码问题，

如果你想提个pr，但是不确定会不会被接收，

如果你想鼓励一下作者，

如果你想发红包给作者，

可以加我微信号，简单线索：`YWlyeWxhbmQ=`

（微信不用于任何使用问题咨询，不要问任何代码使用问题，也不要问在不在，否则拉黑。）
