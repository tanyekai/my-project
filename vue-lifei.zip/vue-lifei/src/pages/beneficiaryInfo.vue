<template>
  <!-- <scroller lock-x> -->
  <div>
    <group v-for="item in infoList" :key="item" style="padding:2%;">
       <cell title="用药人信息" style='color:#3385ff;font-size:18px'>
        <svg class="icon" slot='icon' style='color:#409eff'>
          <use xlink:href="#icon-huanzhe1"></use>
        </svg>
      </cell>
      <cell title="姓名" :value="item.name"></cell>
      <cell title="身份证" :value="item.idNum"></cell>
      <cell title="手机" :value="item.mobile"></cell>
      <cell title="医保卡号" :value="item.medicalCareCard"></cell>
      <cell title="身高" :value="height"></cell>
      <cell title="体重" :value="weight"></cell>
      <cell title="与持卡人关系" :value="relation"></cell>
      <cell title="备注"  primary="content" :value="item.remark"></cell>
      <!-- <cell title="年龄" :value="item.age"></cell>
      <cell title="创建时间" :value="item.createTime"></cell> -->

    </group>
    <flexbox style='' class='addAddressBtn' v-show="addButtonDisplay">
      <flexbox-item>
        <router-link to="/addBeneficiary">
          <div class="total">
            <svg class="icon" slot='icon'>
                    <use xlink:href="#icon-xitongjiahao"></use>
                  </svg>
            <span>新增用药人</span>
          </div>
        </router-link>
      </flexbox-item>
    </flexbox>
  </div>
  <!-- </scroller> -->
</template>

<script>
  import Api from '@/api/patient';
  import Api_patient from '@/api/patient';
  import {
    TransferDom,
    Popup,
    Group,
    Cell,
    XButton,
    XSwitch,
    Toast,
    XInput,
    PopupRadio,
    AlertModule,
    FlexboxItem,
    Flexbox,
    Scroller
  } from 'vux'
  export default {
    directives: {
      TransferDom
    },
    components: {
      Popup,
      Group,
      Cell,
      XSwitch,
      Toast,
      XButton,
      XInput,
      PopupRadio,
      AlertModule,
      FlexboxItem,
      Flexbox,
      Scroller
    },
    data() {
      return {
        name: '',
        relation: '',
        height:'',
        weight:'',
        infoList: [],
        addButtonDisplay:true,
        dictCode:'',
      }
    },
    methods: {
      queryPatient() {
        new Promise((resolve, reject) => {
          Api.queryPatient()
            .then(response => {
              this.infoList = response.result;
              if(response.result.length !== 0){
                  this.addButtonDisplay = false;
              }
              this.height = this.infoList[0].height;
              this.weight = this.infoList[0].weight;
              this.relation =  this.infoList[0].relation;
              if(this.height == 0){
                this.height = ''
              }
              if(this.weight == 0){
                this.weight = ''
              }
              this.dictCodeQuery()
              console.log('用药人信息', this.infoList)
            })
            .catch(error => {
              reject(error);
            });
        });
      },
       // 数据字典查询
      dictCodeQuery() {
        new Promise((resolve, reject) => {
          Api_patient.dictCodeQuery()
            .then(response => {
              this.dictCode = response.result
              this.relation = this.dictCode[this.relation] 
            })
            .catch(error => {
              reject(error);
            });
        });
      },
    },
    mounted() {
      this.queryPatient()
      
    }
  }
</script>

<style lang="less" scoped>
  @import '~vux/src/styles/close.less';
  .name,
  .relationship {
    color: #000;
    font-weight: 700;
    font-size: 16px;
  }
  .left,
  .right {
    color: #000;
    font-size: 16px;
  }
  .addAddressBtn {
    background-color: #fff;
    position: fixed;
    bottom: 0;
    z-index: 999;
    font-size: 18px;
  }
  .total,
  .totalNum {
    text-align: center;
    height: 60px;
    line-height: 60px;
    color: #007aff;
  }
  /*= effect-3 css start =*/
  .single-member {
    width: 280px;
    margin: 0 auto;
    margin-top: 20%;
    background-color: #fff;
    text-align: center;
    position: relative;
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
  }
  .member-image img {
    max-width: 100%;
    vertical-align: middle;
  }
  h3 {
    font-size: 24px;
    font-weight: normal;
    margin: 10px 0 0;
    text-transform: uppercase;
  }
  h5 {
    font-size: 16px;
    font-weight: 300;
    margin: 0 0 15px;
    line-height: 22px;
  }
  p {
    font-size: 14px;
    font-weight: 300;
    line-height: 22px;
    padding: 0 30px;
    margin-bottom: 10px;
  }
  .social-touch a:hover {
    opacity: 1;
    transition: 0.3s;
  }
  .effect-3 {
    max-height: 302px;
    min-height: 302px;
    overflow: hidden;
  }
  .effect-3 h3 {
    padding-top: 7px;
    line-height: 33px;
  }
  .effect-3 .member-image {
    border-bottom: 5px solid #e5642b;
    transition: 0.4s;
    height: 212px;
    width: 100%;
    display: inline-block;
    float: none;
    vertical-align: middle;
  }
  .effect-3 .member-info {
    transition: 0.4s;
  }
  .effect-3 .member-image img {
    width: 100%;
    vertical-align: bottom;
  }
  .effect-3 .social-touch {
    background-color: #e5642b;
    float: left;
    left: 0;
    bottom: 0;
    overflow: hidden;
    padding: 5px 0;
    width: 100%;
    transition: 0.4s;
  }
  .effect-3:hover .member-image {
    border-bottom: 0;
    border-radius: 0 0 50px 50px;
    height: 81px;
    display: inline-block;
    overflow: hidden;
    width: 109px;
    transition: 0.4s;
  }
  /*= effect-3 css end =*/
</style>
