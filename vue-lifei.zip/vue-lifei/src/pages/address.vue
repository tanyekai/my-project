<template>
  <div>

    <flexbox style='' class='addAddressBtn'>
      <flexbox-item>
        <div class="total" @click='addAddress'>
          <svg class="icon" slot='icon'>
              <use xlink:href="#icon-xitongjiahao"></use>
            </svg>
          <span>新增收货地址</span>
        </div>
      </flexbox-item>
    </flexbox>
    <swipeout style=''>
      <swipeout-item transition-mode="follow" v-for="item in addressList" :key="item" @click.native='goBack(item.id,item.provinceCode,item.cityCode,item.districtCode)'>
        <div slot="right-menu">
          <swipeout-button @click.native="pageJump(item.id)" style='backgroundColor:#409eff'>{{'编辑'}}</swipeout-button>
          <swipeout-button @click.native="cut(item.id)" type="warn">{{'删除'}}</swipeout-button>
        </div>
        <div slot="content" class='demo-content vux-1px-t itemAddress'>
          <p>
            <span>收件人 ：</span>
            <span style='color:#007aff'>{{item.receiver}}</span>
          </p>
          <p>
            <span>手机 ：</span>
            <span style='color:#007aff'>{{item.mobile}}</span>
          </p>
          <p>
            <span>地址 ：</span>
            <span style='color:#007aff'>{{item.provinceCode + item.cityCode + item.districtCode}}</span>
            <span style='color:#007aff'>{{item.fullAddress}}</span>
          </p>
        </div>
      </swipeout-item>
    </swipeout>
  </div>
</template>
<script>
  import Api from "@/api/thePurchase";
  import Api_address from "@/api/address";
  import {
    Flexbox,
    FlexboxItem,
    Cell,
    CellBox,
    CellFormPreview,
    Group,
    Badge,
    FormPreview,
    XSwitch,
    base64,
    Swipeout,
    SwipeoutItem,
    SwipeoutButton
  } from "vux";
  export default {
    components: {
      Flexbox,
      FlexboxItem,
      Cell,
      CellBox,
      CellFormPreview,
      Group,
      Badge,
      FormPreview,
      XSwitch,
      Swipeout,
      SwipeoutItem,
      SwipeoutButton
    },
    data() {
      return {
        urbanChina: [],
        addressList: [],
        type: this.$route.query.type,
      };
    },
    //初始化
    mounted() {
      this.inquiryProvince();
    },
    methods: {
      // 查询中国所有省市区
      inquiryProvince() {
        new Promise((resolve, reject) => {
          Api.chinaQuery()
            .then(response => {
              this.urbanChina = response.result;
              this.query();
            })
            .catch(error => {
              reject(error);
            });
        });
      },

      // 地址管理(已有地址显示)
      query() {
        new Promise((resolve, reject) => {
          Api_address.query()
            .then(response => {
              this.addressList = response.result;
              this.addressList.forEach(v => {
                for (var key in v) {
                  this.urbanChina.forEach(val => {
                    if (val.value === v[key]) {
                      v[key] = val.name;
                    }
                  });
                }
              });
            })
            .catch(error => {
              reject(error);
            });
        });
      },

      //删除地址
      cut(id) {
        new Promise((resolve, reject) => {
          Api.deleteAddress(id)
            .then(response => {
              this.inquiryProvince();
              this.query();
            })
            .catch(error => {
              reject(error);
            });
        });
      },

      // 路由跳转 编辑页面
      pageJump(id) {
        this.$router.push({
          path: "/editAddress",
          query: {
            id: id,
          }
        });
      },
      
      //  下单取收货地址id
      goBack(id, provincial, city, district) {
        if (this.type == 'deliveryToHome') {
          this.$router.push({
            path: "/deliveryToHome",
            query: {
              addressId: id,
              provincial: base64.encode(provincial),
              city: base64.encode(city),
              district: base64.encode(district)
            }
          });
        } else {
          // alert("other");
        }
      },
      //  添加收获地址
      addAddress() {
        if (this.type == 'deliveryToHome') {
          this.$router.push({
            path: "/addAddress",
            query: {
              type: this.type
            }
          });
        } else {
          this.$router.push('/addAddress');
        }
      }
      
    }
  };
</script>

<style lang="less">
  @import "~vux/src/styles/1px.less";
  .addAddressBtn {
    background-color: #fff;
    position: fixed;
    bottom: 0;
    z-index: 999;
    font-size: 18px;
  } // 新增地址按钮
  .itemAddress {
    margin-bottom: 20px; // padding-left:2px;
    padding-left: 6%;
    padding-top: 2%;
    padding-bottom: 2%;
  } // 详细地址
  .itemCol {
    overflow: hidden;
    height: 30px;
    line-height: 30px;
  }
  .fontColor {
    color: #007aff
  }
  .left {
    float: left;
    text-align: right;
    width: 80px;
  }
  .right {
    float: right;
  }
  .slide {
    padding: 0 20px;
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.5s cubic-bezier(0, 1, 0, 1) -0.1s;
  }
  .animate {
    max-height: 9999px;
    transition-timing-function: cubic-bezier(0.5, 0, 1, 0);
    transition-delay: 0s;
  }
  .total,
  .totalNum {
    text-align: center;
    height: 60px;
    line-height: 60px;
    color: #007aff;
  }
  .addressManagement {
    background-color: #fff;
    padding: 0 5%;
    color: #007aff;
  }
  .clearfix:before,
  .clearfix:after {
    content: "";
    display: block;
    clear: both;
  }
  .clearfix {
    zoom: 1;
  }
  .addressManagement {
    margin-top: 15px
  } // .addressManagement .addressShow {
  //   // border-bottom: #D9D9D9 1px solid;
  // }
  ;
  .addressManagement p {
    padding: 5px 0;
  }
  .addressManagement p .name {
    float: left;
  }
  .addressManagement p .phone {
    float: left;
    margin-left: 20px;
  }
  .addressDeit p {
    padding: 5px 15px
  }
  .addressManagement .edit {
    float: right;
    display: inline-block;
    width: 20px;
    height: 20px;
  }
  .addressManagement .delete {
    padding-top: 10px;
    float: right;
    display: inline-block;
    width: 20px;
    height: 20px;
  }
  .addressManagement .icon {
    float: right;
    margin-right: -20px;
  }
  .addressManagement .icon-delete {
    margin: -10px -15px;
  }
  .addressManagement .icon-edit {
    margin: 0 -15px;
  }
  .fontColor {
    color: #333333;
    font-weight: 400; // letter-spacing:2px;
  }
</style>
