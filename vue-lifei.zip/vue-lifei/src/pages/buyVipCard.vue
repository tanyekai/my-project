<template>
  <div>
    <group gutter='0%'>
      <!-- 关爱卡展示 -->
      <group gutter='0%' style='padding:10px'>
        <div class="vipCard">
          <img src='../assets/gak.png' alt="">
        </div>
      </group>
      <!-- 关爱卡权益展示 -->
      <div style='padding:0 20px'>
        <p>会员卡299/年 </p>
        <p>会员权益：</p>
        <p>一、镁信会员尊享9.5折合作药店药品福利。</p>
        <p>二、电话预约药品，免费提供送药到家服务。</p>
        <p>三、专业药事服务：执业药师提供体检咨询、个性化预防、保健、用药指导。</p>
        <p>四、管家式医疗服务（专业的全称病案管理，多模式诊断咨询，合作医院门诊VIP预约、高端国际医疗咨询）。</p>
        <p>-关爱卡会员绑定唯一的用药人，用药人不可更改，购药时用药人须和处方名字一致。</p>
        <p>-权益时间为会员卡激活之日起的一个自然年。</p>
      </div>
      <!-- 微信支付按钮 -->
      <box gap="10px 10px" style='margin-top:4%;margin-bottom:0%'>
        <x-button type="primary" style="background-color: #409eff;color:#fff;" @click.native='wxPay()'>微信支付</x-button>
      </box>
      <flexbox style='margin-top:0%;margin-bottom:20%'></flexbox>
    </group>

  </div>
</template>


<script>
  import Api_wxPay from '@/api/wxPay';
  import Api_member from '@/api/member';
  import {
    Group,
    Cell,
    Flexbox,
    FlexboxItem,
    XButton,
    Box,
    Divider
  } from "vux";
  import {
    setTimeout
  } from 'timers';
  export default {
    components: {
      Group,
      Cell,
      Flexbox,
      FlexboxItem,
      XButton,
      Box,
      Divider
    },
    data() {
      return {
        appId: '',
        timeStamp: '',
        nonceStr: '',
        package: '',
        signType: '',
        paySign: '',
        vipCardProductId: localStorage.getItem("vipCardProductId"),
        orderType:localStorage.getItem("orderType"),
        cardNo:localStorage.getItem("cardNo"),
        orderNo: '',
      }
    },

    mounted() {
      this.isVip();
      if (typeof WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
          document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
        } else if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      } else {
        onBridgeReady();
      }
    },

    methods: {

      wxPay() {
        let that = this;
        new Promise((resolve, reject) => {
          Api_wxPay.wxPay(that.orderType, that.vipCardProductId, that.cardNo)
            .then(response => {
              that.appId = response.result.appId
              that.timeStamp = response.result.timeStamp
              that.nonceStr = response.result.nonceStr
              that.package = response.result.packageWx
              that.signType = response.result.signType
              that.paySign = response.result.paySign
              that.orderNo = response.result.orderNo
              that.$wechat.config({
                debug: false,
                appId: response.result.appId,
                timeStamp: response.result.timeStamp,
                nonceStr: response.result.nonceStr,
                signType: response.result.signType,
                paySign: response.result.paySign,
                jsApiList: ['chooseWXPay']
              });
              that.onBridgeReady();
            })
            .catch(error => {
              that.$vux.toast.text(error);
              reject(error);
            });
        });
      },

      onBridgeReady() {
        let that = this;
        WeixinJSBridge.invoke(
          'getBrandWCPayRequest', {
            "appId": that.appId, //公众号名称，由商户传入     
            "timeStamp": that.timeStamp, //时间戳，自1970年以来的秒数     
            "nonceStr": that.nonceStr, //随机串     
            "package": that.package,
            "signType": that.signType, //微信签名方式：     
            "paySign": that.paySign //微信签名 
          },
          function (res) {
            if (res.err_msg == "get_brand_wcpay_request:ok") {
              new Promise((resolve, reject) => {
                Api_wxPay.callBack(that.orderNo)
                  .then(response => {
                    localStorage.removeItem("vipCardProductId");
                    localStorage.removeItem("orderType");
                    localStorage.removeItem("cardNo");

                    if (sessionStorage.getItem("orderSource") == 'deliveryToHome') {
                      sessionStorage.removeItem("orderSource");
                      that.$router.push('/deliveryToHome');
                    } else {
                      that.$router.push('/payVipSuccess');
                    }
                  })
                  .catch(error => {
                    that.$vux.toast.text(error);
                    reject(error);
                  });
              });
            } else {
              new Promise((resolve, reject) => {
                Api_wxPay.wxPayOrderQuery(that.orderNo)
                  .then(response => {

                  })
                  .catch(error => {
                    reject(error);
                  });
              });
            }
          }
        );
      },

      isVip() {
        new Promise((resolve, reject) => {
          Api_member.profile()
            .then(response => {
              if (response.result.vipStatus == '2') {
                this.showPlugin();
              }
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },

      showPlugin() {
        let that = this;
        that.$vux.confirm.show({
          title: '亲',
          content: '您已经是尊贵的会员了',
          onCancel() {
            WeixinJSBridge.call('closeWindow');
          },
          onConfirm() {
            that.$router.push('/vipInfo');
          }
        })
      }
    }
  };

</script>


<style lang="less" scoped>
  @import '~vux/src/styles/1px.less';
  .wxPayLabel {
    color: #fff;
    margin: 4% 0 2% 4%;
  }

  .wxPayInfo {
    line-height: 30px;
    color: #000;
  }

  .wxPayPrice {
    text-decoration: line-through;
    text-align: center;
    margin-top: 20%;
    font-family: 'console'
  }

  .wxPaySale {
    text-align: center;
    font-size: 18px; // text-shadow:5px 2px 6px #888;
    font-family: 'SimHei'
  }

  .wxPayVipCard {
    // background-color: red;
    margin-top: 10%;
    background-image: linear-gradient(45deg, #e2ab2e, #f5c352);
    box-shadow: -2px 3px 10px rgba(226, 171, 47, .5);
    border-radius: .2rem;
    color: #fff;
  }

  .icon {
    color: #409eff;
  }

  .vipCard {
    margin: 0 auto;
    margin-top: 5%;
    width: 90%; // height: 200px;
    img {
      width: 100%;
      height: 100%;
    }
  }

</style>
