<template>
  <div>
    <group gutter='10%' style='margin-bottom:4%'>
      <cell title="会员卡激活" class='label'>
        <svg class="icon" slot='icon'>
          <use xlink:href="#icon-huiyuan1"></use>
        </svg>
      </cell>
      <!-- 手机号 -->
      <cell title="手机" v-model='phoneNo'></cell>
      <!-- 会员卡号，通过扫一扫获取 -->
      <cell title="会员卡号">
        <button class='scanBtn' @click='scan' ref='scanBtn' v-if='scanBtnShow'>点击扫描条形码</button>
        <span slot>{{ cardNo }}</span>
      </cell>
    </group>
    <group>
      <!-- 姓名 -->
      <x-input v-model='name' text-align='right' placeholder-align='right' title="姓名" placeholder="请输入姓名" is-type="china-name"></x-input>
      <!-- 身份证号码 -->
      <x-input v-model='idNum' text-align='right' placeholder-align='right' title="身份证" placeholder="请输入身份证号码" :min="18" :max="18"></x-input>
      <x-input></x-input>
      <!-- 按钮 -->
      <flexbox class='btn'>
        <flexbox-item style='padding:0 4%'>
          <x-button type="primary" style="background-color: #409eff;color:#fff;" @click.native='next'>下一步</x-button>
        </flexbox-item>
      </flexbox>
    </group>
  </div>
</template>

<script>
  import Api from '@/api/member';
  import wx from 'weixin-js-sdk';
  import {
    Group,
    XInput,
    Cell,
    Selector,
    XButton,
    Flexbox,
    FlexboxItem,
    AlertModule
  } from 'vux';
  export default {
    components: {
      Group,
      XInput,
      Cell,
      Selector,
      XButton,
      Flexbox,
      FlexboxItem,
      AlertModule
    },
    data() {
      return {
        phoneNo: '',
        name: '',
        idNum: '',
        scanBtnShow: true,
        cardNo: '',
        vipCardProductId: ''
      }
    },
    methods: {
      next() {
        if (!this.cardNo) {
          this.$vux.toast.text("请扫描条形码获取会员卡号");
          return false;
        } else if (!this.name) {
          this.$vux.toast.text("请填写姓名");
          return false;
        } else if (!this.idNum) {
          this.$vux.toast.text("请填写身份证号");
          return false;
        }
        new Promise((resolve, reject) => {
          Api.update(this.name, this.idNum)
            .then(response => {
              localStorage.setItem('orderType', '02');
              localStorage.setItem('vipCardProductId', this.vipCardProductId);
              localStorage.setItem('cardNo', this.cardNo);
              this.$router.push('/buyVipCard');
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });

      },


      // 微信sdk签名配置
      signature() {
        new Promise((resolve, reject) => {
          Api.signature(location.href.split('#')[0])
            .then(response => {
              wx.config({
                debug: false,
                appId: response.result.appId, //公众号的唯一标识
                timestamp: response.result.timestamp, //地图签名时间戳
                nonceStr: response.result.nonceStr, //生成签名的随机串
                signature: response.result.signature, //签名，见附录1
                jsApiList: ["scanQRCode"]
              });
              wx.error(function (res) {
                // alert('error' + res);
              });
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },

      // 扫描条形码
      scan() {
        let that = this;
        wx.ready(function () {
          wx.scanQRCode({
            desc: 'scanQRCode desc',
            needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
            scanType: ["barCode"], // 可以指定扫二维码还是一维码，默认二者都有
            success: function (res) {
              that.scanBtnShow = false;
              that.cardNo = res.resultStr.slice(-12)
              that.getCardNo();
            },
            error: function (res) {
              if (res.errMsg.indexOf('function_not_exist') > 0) {
                alert('版本过低请升级')
              }
            }
          });
        })
      },

      // 通过扫一扫得到的卡号获取vipCardProductId
      getCardNo() {
        new Promise((resolve, reject) => {
          Api.cardNo(this.cardNo)
            .then(response => {
              this.vipCardProductId = response.result.productId;
            })
            .catch(error => {
              this.scanError('抱歉', error);
              reject(error);
            });
        });
      },

      scanError(title, info) {
        let that = this;
        this.$vux.alert.show({
          title: title,
          content: info,
          onShow() {},
          onHide() {
            location.reload();
          }
        })
      },

      profile() {
        new Promise((resolve, reject) => {
          Api.profile()
            .then(response => {
              this.phoneNo = response.result.phoneNo;
            })
            .catch(error => {
              reject(error);
            });
        });
      },

      isVip() {
        new Promise((resolve, reject) => {
          Api.isVip()
            .then(response => {
              if (response.result) {
                this.showPlugin();
              }
            })
            .catch(error => {
              reject(error);
            });
        });
      },

      showPlugin() {
        let self = this;
        this.$vux.confirm.show({
          title: '亲',
          content: '您已经是尊贵的会员了',
          onConfirm() {
            self.$router.push('/myAccount');
          },
          onCancel() {
            WeixinJSBridge.call('closeWindow');
          }
        });
      },
    },

    created() {
      this.isVip();
      this.profile();
    },
    mounted() {
      this.signature();
    }
  }

</script>

<style lang="less" scoped>
  .label {
    color: #409eff;
    font-size: 16px;
  }

  .btn {
    margin-top: 40%;
    margin-bottom: 40%;
  }

  .scanBtn {
    padding: 6px 6px;
    background-color: #409eff;
    color: #fff;
    border: 0;
    border-radius: 4px;
    font-size: 14px;
  }

</style>
