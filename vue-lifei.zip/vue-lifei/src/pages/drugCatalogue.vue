<template>
  <div class="drugCatalogue">
    <div class="searchHeader">
      <div class="srarchMain" style="width:96%;margin:0 auto;">
        <input type="text" v-model="searchValue" placeholder="请搜索您需要的药品">
        <b class="logoIcon"></b>
        <!-- <b class="searchIcon"></b> -->
        <div class="search" @click="inquireDrugstore">
          <svg class="icon searchIcon" slot='icon'>
                  <use xlink:href="#icon-sousuo"></use>
                </svg>
        </div>
      </div>
      <group>
        <cell title="药品名称" value="经销药店"></cell>
        <!-- <cell v-for="item in drugName" :key="item" :title="item.drugName" :value="item.count" @click.native="pageJump(item.id)" arrow-direction="left"></cell> -->
      </group>
    </div>
    <div class="dragMain">
      <div class="dragList" v-for="item in drugName" :key="item" @click="pageJump(item.count,item.id)">
        <p>{{item.commonName}}</p>
        <p>{{item.drugName}}<span class="spec">{{item.spec}}</span> <span class="num">{{item.count}}</span> </p>
        <p>{{item.manufacturer}}</p>
      </div>
    </div>
    <toast v-model="showPositionValue" type="text" :time="1500" is-show-mask :text="text" :position="position" style="width:60%;"></toast>
  </div>
</template>


<script>
  import Api from "@/api/thePurchase";
  import {
    Group,
    Cell,
    Selector,
    XAddress,
    ChinaAddressV4Data,
    XButton,
    Toast,
    Value2nameFilter as value2name
  } from "vux";
  export default {
    components: {
      Group,
      Cell,
      Selector,
      XAddress,
      ChinaAddressV4Data,
      XButton,
      Toast
    },
    data() {
      return {
        addressData: ChinaAddressV4Data,
        showAddress: false,
        showContent004: false,
        value: [],
        searchValue: "",
        value1: [],
        message: "zhong",
        code: "1",
        drugName: [],
        test: [],
        drugId: [],
        text: "",
        position: "",
        showPositionValue: false,
        count: '',
      };
    },
    methods: {
      // 模糊搜索药店
      // 药品搜索
      inquireDrugstore() {
        if (this.searchValue == "") {
          this.text = "搜索内容不能为空";
          this.showPosition("top");
          return;
        }
        new Promise((resolve, reject) => {
          Api.drugstoreInquiries(this.searchValue)
            .then(response => {
              console.log(response.result);
              this.drugName = response.result;
              function compare(property) {
                return function(a, b) {
                  var value1 = a[property];
                  var value2 = b[property];
                  return value2 - value1;
                }
              }
              console.log(this.drugName.sort(compare('count')))
            })
            .catch(error => {
              this.text = "该药品不存在";
              this.showPosition("top");
              reject(error);
            });
        });
      },
      // 路由跳转
      pageJump(count, id) {
        if (count != '0') {
          this.$router.push({
            path: "/choosePharmacy",
            query: {
              id: id
            }
          });
        }
      },
      showPosition(position) {
        this.position = position;
        this.showPositionValue = true;
      }
    }
  };
</script>

<style lang="less">
  @import "~vux/src/styles/1px.less";
  .drugCatalogue {
    clear: both;
    width: 100%;
  }
  .vux-toast-top {
    width: 11em !important;
  }
  .weui-search-bar {
    border-radius: 20px 0 0 20px !important;
  }
  .drugCatalogue .weui-search-bar:after {
    border-bottom: none;
  }
  .drugCatalogue .weui-search-bar:before {
    border-top: none;
  }
  .srarchMain {
    position: relative;
  }
  .searchHeader {
    width: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 99;
    background-color: #fbf9fe;
  }
  input {
    padding: 0;
    font-size: 14px;
    margin: 0;
    width: 70%;
    height: 35px;
    margin-top: 22px;
    outline: none;
    border: 1px solid #e5e5e5;
    padding-left: 12%;
    border-radius: 30px;
  }
  .search {
    width: 14%;
    height: 30px;
    float: right;
    border: none;
    margin-top: 25px;
    font-size: 18px;
    text-align: center;
    // color: #007aff;
    // opacity: 0.6;
    line-height: 40px;
    // background: url("../assets/searchIcon.png");
    background-repeat: no-repeat;
    background-size: contain;
  }
   .search .searchIcon{
     font-size: 35px;
     margin-top: -10px;
   }
  .logoIcon {
    display: inline-block;
    width: 25px;
    height: 25px;
    background: url("../assets/logoIcon2.png");
    background-repeat: no-repeat;
    background-size: contain;
    position: absolute;
    top: 27px;
    left: 3%;
  }
  .dragMain {
    margin-top: 128px;
  }
  .dragList {
    width: 100%;
    background-color: #fff;
    border-bottom: 1px solid #D9D9D9;
    padding: 10px 0;
  }
  .dragList p {
    // width: 80%;
    padding: 0 20px;
    color: #333;
  }
  .dragList p .num {
    float: right;
    color: #333333;
  }
  .dragList p .spec {
    margin-left: 10px;
  }
</style>