<template>
  <div>
    <div class='map'>
      <el-amap vid="amapDemo" :zoom="zoom" :center="center">
        <el-amap-marker :position="position" showShadow='true'>
        </el-amap-marker>
      </el-amap>
    </div>
    <group gutter='0' style="padding-top:200px;">
      <cell inline-desc="您搜索的药店"></cell>
    </group>
    <group gutter='0%' :showContent="showContent" v-for="(item,index) in listOfDrugstores" :key="item">
      <cell :title="item.name" @click.native="mobileShow(index,item.longitude,item.latitude)" :inline-desc="item.address">
        <span class="addressIcon" style="display:inline-block;width:30px;height:30px;" @click="getLocation(item.longitude,item.latitude,item.name,item.address)"></span>
      </cell>
      <!-- <form-preview :header-label="$t('联系电话')" :header-value='item.mobile' class="slide" :class="showContent[index]?'animate':''" style='backgroundColor:#f1f1f1'></form-preview> -->
      <div class="slide" :class="showContent[index]?'animate':''" style='color:#007aff;height:auto;'>
        <p>联系电话：{{item.mobile}}</p>
        <p>服务时间：</p>
        <p>我们的服务：</p>
        <p>
          <b>专业购药：</b>
          <br>专业的药师指导，全程温度监控</p>
        <p>
          <b>慈善活动：</b>
        </p>
      </div>
    </group>
  </div>
</template>

<script>
  import Api from "@/api/thePurchase";
  import "@/api/thePurchase";
  import wx from 'weixin-js-sdk';
  import {
    Panel,
    Group,
    Radio,
    Cell,
    FormPreview
  } from "vux";
  export default {
    components: {
      Cell,
      Panel,
      Group,
      Radio,
      FormPreview
    },
    data() {
      return {
        zoom: 14, //地图放大度
        center: [121.4583800000, 31.1902300000],
        position: [121.4583800000, 31.1902300000],
        name: "上海众协药店有限公司",
        time: "上海市长宁区城区中山西路1438号",
        showContent: [],
        listOfDrugstores: [],
        drugId: this.$route.query.id, //路由传参接受
        url: location.href.split('#')[0], //微信地图传参
        appId: "",
        timestamp: '',
        nonceStr: '',
        signature: '',
        ticket: '',
        latitude: '31.21515044',
        longitude: '121.5273285',
      };
    },
    mounted() {
      this.weChatMapApi();
      this.displayDrugstore();
      this.creatShowArr(12);
    },
    methods: {
      //展示药店
      displayDrugstore() {
        new Promise((resolve, reject) => {
          Api.drugstoreDisplay(this.drugId)
            .then(response => {
              this.listOfDrugstores = response.result;
            })
            .catch(error => {
              reject(error);
            });
        });
      },
      //药店手机号码显示  
      mobileShow(index, longitude, latitude) {
        this.showContent[index] = !this.showContent[index];
        this.showContent = Object.assign([], this.showContent);
        this.position = [longitude, latitude]
        this.center = [longitude, latitude]
        console.log(longitude, latitude);
      },
      //创建记录显示隐藏状态数组
      creatShowArr(length) {
        for (let index = 0; index < length; index++) {
          this.showContent.push(0);
        }
      },
      //微信地图api调取
      getLocation(longitude, latitude, name, address) {
        var lat = Number(latitude);
        var lng = Number(longitude);
        wx.openLocation({
          latitude: lat, // 纬度，浮点数，范围为90 ~ -90
          longitude: lng, // 经度，浮点数，范围为180 ~ -180。
          name: name, // 位置名
          address: address, // 地址详情说明
          scale: 14, // 地图缩放级别,整形值,范围从1~28。默认为最大
          infoUrl: 'http://wxbms.yiyaogo.com' // 在查看位置界面底部显示的超链接,可点击跳转
        });
      },
      weChatMapApi() {
        var _this = this;
        new Promise((resolve, reject) => {
          Api.WeChatMap(this.url)
            .then(response => {
              console.log(response);
              wx.config({
                debug: false,
                appId: response.result.appId, //公众号的唯一标识
                timestamp: response.result.timestamp, //地图签名时间戳
                nonceStr: response.result.nonceStr, //生成签名的随机串
                signature: response.result.signature, //签名，见附录1
                jsApiList: ['openLocation',
                  'getLocation'
                ]
              });
              wx.ready(function () {
                wx.getLocation({
                  type: 'wgs84', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
                  success: function (res) {
                    var latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
                    var longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
                    var speed = res.speed; // 速度，以米/每秒计
                    var accuracy = res.accuracy; // 位置精度  
                    _this.latitude = latitude;
                    _this.longitude = longitude;
                    _this.position = [longitude, latitude];
                    _this.center = [longitude, latitude];
                  }
                });
              });
              // wx.error(function(res) {
              //   alert('jjjj' + res);
              // });
            })
            .catch(error => {
              reject(error);
            });
        });
      },
    },
  };

</script>


<style lang="less" scoped>
  .slide {
    padding: 0 20px;
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.5s cubic-bezier(0, 1, 0, 1) -0.1s;
  }

  .slide p {
    padding: 10px 5px;
    border-bottom: 1px dashed #ccc;
  }

  .animate {
    max-height: 9999px;
    transition-timing-function: cubic-bezier(0.5, 0, 1, 0);
    transition-delay: 0s;
  }

  .map {
    width: 100%;
    height: 200px;
    position: fixed;
    z-index: 999;
  }

  .addressIcon {
    background: url("../assets/addressIcon.jpg") no-repeat;
    background-size: contain;
  }

</style>
