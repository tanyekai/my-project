<template>
  <div>
    <!-- <flexbox-item style='backgroundColor:#404040;color:#fff'>
        <p class='info'>请完善用户认证的信息</p>
    </flexbox-item> -->
    <flexbox style='backgroundColor:#404040'>
      <flexbox-item>
        <div class="info">请完善用户认证的信息</div>
      </flexbox-item>
    </flexbox>
    
    <group gutter=''>
      <cell title="银行卡信息"  is-link :link="{path:'/bankCardVerifiedInfo'}">
      </cell>
    </group>
  </div>
</template>


<script> 
import { Group, Cell,Flexbox, FlexboxItem} from "vux";
export default {
  components: {
    Group,
    Cell,
    Flexbox,
    FlexboxItem,
  }
};
</script>

<style lang="less">
@import '~vux/src/styles/1px.less';
.info {
    text-align: center;
    height: 60px;
    line-height: 60px;
    color: #fff;
}
</style>