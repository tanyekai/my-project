<template>
  <div>
    <group gutter='10%' style='margin-bottom:4%'>
      <cell title="会员信息填写" class='label'>
        <svg class="icon" slot='icon'>
                <use xlink:href="#icon-huiyuan1"></use>
              </svg>
      </cell>
      <!-- 手机号 -->
      <cell title="手机" v-model='phoneNo'></cell>
    </group>
    <group>
      <!-- 姓名 -->
      <x-input v-model='name' text-align='right' placeholder-align='right' title="姓名" placeholder="请输入姓名" is-type="china-name"></x-input>
      <!-- 性别 -->
      <!-- <selector title='性别' :options='list' v-model='sex'></selector> -->
      <!-- 身份证号码 -->
      <x-input v-model='idNum' text-align='right' placeholder-align='right' title="身份证" placeholder="请输入身份证号码" :min="18" :max="18"></x-input>
      <x-input></x-input>
      <!-- 注册协议 -->
      <div class="agreement">
        <a href="javascript:;" @click="agreement_Show()">《注册协议》</a>
        <a href="javascript:;" @click="platformService()">《平台服务协议》</a>
        <div v-show="readProtocol" @click="setReadProtocol()" style="float:right;">
          <span style="float: right;margin-left: -11px">已同意</span>
          <svg class="icon" slot='icon' style="width:24px;margin-top:2px;">
                  <use xlink:href="#icon-duihaocheckmark17"></use>
                </svg>
        </div>
        <div v-show="unreadProtocol" @click="setUnreadProtocol()" style="float:right;">
          <span style="float: right;margin-left: -10px">请勾选</span>
          <svg class="icon" slot='icon' style="width:20px;margin-top:2px;">
                  <use xlink:href="#icon-yuancircle46"></use>
                </svg>
        </div>
      </div>
      <!-- 按钮 -->
      <flexbox class='btn'>
        <flexbox-item style='padding:0 4%'>
          <x-button type="primary" style="background-color: #409eff;color:#fff;" @click.native='next'>下一步</x-button>
        </flexbox-item>
      </flexbox>
    </group>
    <!-- 注册协议 -->
    <div class="agreementShow" v-show="agreementShow">
      <div class="registrationAgreement">
        <p style="margin-top: 10px;text-align: center;border: none;padding: 0">
          <a></a><strong><span style="font-size:16px !important;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">镁信健康微信平台注册协议</span></strong>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">重要须知：</span></strong>
        </p>
        <p style="margin: 10px 30px;background: white">
          <span style="font-family: 微软雅黑, sans-serif; font-size: 14px;">镁信健康微信平台是指由上海镁信健康科技有限公司（“镁信健康”）开发并运营的平台（微信公众号：镁信健康，以下统称“微信平台”）。</span>
        </p>
        <p style="margin-bottom:4px;text-indent:28px">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">本协议双方为镁信健康与申请在微信平台注册的用户（以下简称“您”）</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1.<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您一旦点击同意本协议并完成注册程序，本协议立即成立并生效，您成为平台的正式用户。您确认：本协议条款是处理双方权利义务的依据，始终有效，法律另有强制性规定或双方另有特别约定的，依其规定或约定。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2.<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">请您务必仔细阅读并充分理解本协议包含的各个条款，特别是有关镁信健康微信平台免责条款，以及对您权利限制条款。若您不同意接受或无法理解本协议任何条款的，请立即停止注册操作。您点击同意本协议后，即视为您接受并同意遵守本协议的约定，亦视为您确认自己具有注册微信平台用户等相应的权利能力和行为能力，能够独立承担法律责任。</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3.<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">镁信健康微信平台有权根据实际情况不时地修订并更新本协议。镁信健康微信平台将随时通过微信公告本协议修订情况。经修订的本协议一经公布，即视为向您送达，立即生效，并代替原来的协议，但如修订涉及改变个人信息收集、处理、利用规则的，将提示您予以同意。镁信健康微信平台建议您在使用镁信健康微信平台之前阅读本协议及平台的公告。如果本协议中任何一条被视为废止、无效或因任何理由不可执行，该条应视为可分的且并不影响任何其余条款的有效性和可执行性。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4.<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">本协议受限于包括但不限于《中华人民共和国合同法》等相关法律法规的限制和规定，本协议内容有任何与前述法规相冲突的，以前述法律法规的内容为准。镁信健康微信平台保留根据前述法律法规及其不时的更新对本协议进行修改和更新并随时通过微信平台进行公告，本协议以镁信健康微信平台不时公布的最新版本为准。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">使用限制</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">镁信健康微信平台中全部内容的知识产权（包括但不限于商标权、专利权、著作权、商业秘密等）均属于镁信健康微信平台所有，该等内容包括但不限于文本、数据、文</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">章、设计、源代码、软件、图片、照片及其他全部信息（以下称“微信平台内容”）。微信平台内容受中华人民共和国著作权法、各国际版权公约以及其他知识产权法律法规与公约的保护。未经镁信健康微信平台事先书面同意，您不应以任何方式复制、模仿、传播、出版、公布、展示网站内容，包括但不限于电子的、机械的、复印的、录音录像的方式和形式等。您承认微信平台内容是属于镁信健康微信平台的财产。未经镁信健康微信平台书面同意，您亦不得将镁信健康微信平台包含的资料等任何内容镜像到任何其他网站或者服务器。任何未经授权对微信平台内容的使用均属于违法行为，镁信健康微信平台将追究您的法律责任。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">镁信健康微信平台只接受符合中华人民共和国法律（不包括香港特别行政区、澳门特别行政区和台湾地区的法律法规）规定的具有完全民事权利能力和民事行为能力，能独立行使和承担本规则项下权利义务的主体注册。如您不符合资格，请勿注册。镁信健康微信平台保留随时中止或终止您用户资格的权利。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">注册成功后，请您注意保管注册账户及登录密码。任何您的注册账户进行的操作均视为您本人操作，且具有不可逆转性。因操作所产生的电子信息记录和痕迹均为您行为的有效凭证，您不得以任何理由要求取消或变更，且应当承担由此产生的全部责任。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您应当确保账户及登录密码的机密安全，并对利用该用户账户及密码所进行的一切行动及言论负完全责任，并同意：</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不对其他任何人泄露账户或密码，亦不可使用其他任何人的账户或密码。镁信健康微信平台不对因黑客、病毒或会员的保管疏忽等非镁信健康微信平台原因导致会员的用户账户遭他人非法使用承担任何责任；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）冒用他人账户及密码的，镁信健康微信平台及其合法授权主体保留追究实际使用人连带责任的权利。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">5)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您有义务在注册时提供自己的真实、准确、最新、完整的资料，并保证诸如电子邮件地址、联系电话、联系地址、邮政编码等内容的有效性及安全性。您有义务维持并立即更新您的注册资料，确保其为真实、准确、最新、有效及完整。若您提供任何错误、虚假、过时或不完整的资料，或者镁信健康微信平台有合理的理由怀疑资料为错误、虚假、过时或不完整，镁信健康微信平台有权暂停或封存您的注册账户，并拒绝您使用镁信健康微信平台的部份或全部功能。在此情况下，镁信健康微信平台不承担任何责任，并且您同意自行负担因此所产生的直接或间接的任何支出或损失。如您因网上交易与其他用户产生诉讼的，其他用户有权通过司法部门要求微信平台提供相关资料。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">6)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">本协议依据国家相关法律法规规章制定，您同意严格遵守以下义务：</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不得传输或发表: 煽动抗拒、破坏宪法和法律、行政法规实施的言论，煽动颠覆国家政权，推翻社会主义制度的言论，煽动分裂国家、破坏国家统一的言论，煽动民族仇恨、民族歧视、破坏民族团结的言论、破坏国家宗教政策、宣扬邪教和封建迷信的、散布谣言、扰乱社会秩序、破坏社会稳定的；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）从中国大陆向境外传输资料信息时必须遵守中国有关法律法规；</span><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">[</span></em></strong><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">环球：如微信平台服务本身涉及跨境传输，建议明确并需要告知跨境传输的信息内容、范围、目的、方式以及目的地国家等。]</span></em></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不得利用镁信健康微信平台从事窃取商业秘密、窃取个人信息等违法犯罪活动；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不得干扰镁信健康微信平台的正常运转，不得侵入镁信健康微信平台及国家计算机信息系统；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">5</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不得传输或发表任何违法犯罪的、骚扰性的、中伤他人的、辱骂性的、恐吓性的、伤害性的、庸俗的、淫秽的等不文明的信息资料；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">6</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不得传输或发表损害国家社会公共利益和涉及国家安全的信息资料或言论；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">7</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）不得教唆他人从事本条所禁止的行为。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">7)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">除本注册协议、对您适用的其他条款或与您之间另有其他约定外，您不得利用在镁信健康微信平台注册的账户进行经营活动、牟利行为及其他未经镁信健康微信平台许可的行为，包括但不限于以下行为: </span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">用恶意手段或其他方式，为获取优惠、折扣或其他利益而注册账户、下单等行为，影响镁信健康微信平台正常经营秩序的行为；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）发布广告、垃圾邮件；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）任何对说明、其他会员信息或其他内容的下载、转载、收集、衍生利用、复制、出售、转售或其他形式的使用，无论是否通过Robots、Spiders、自动仪器或手工操作；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）镁信健康微信平台相关规则、政策、或网页活动规则中限制、禁止的行为；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">5</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）其他影响镁信健康微信平台对用户账户正常管理秩序的行为。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">8)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您不得利用任何非法手段获取其他会员个人信息，不得将其他会员信息用于任何营利或非营利目的，不得泄露其他会员或权利人的个人隐私，否则镁信健康微信平台有权采取本协议规定的合理措施制止您的上述行为，情节严重的，将提交公安机关进行刑事立案。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">9)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您不得发布任何侵犯他人合法权利的内容；如果有其他会员或权利人发现您发布的信息涉嫌侵犯他人合法权益争议的，这些会员或权利人有权要求镁信健康微信平台删除您发布的信息，或者采取其他必要措施予以制止，镁信健康微信平台将会依法采取这些措施。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">10) </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您应不时关注并遵守镁信健康微信平台不时公布或修改的各类规则规定。镁信健康微信平台保有删除站内各类不符合法律政策或不真实的信息内容而无须通知您的权利。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">11) </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">若您未遵守本协议相关规定的，镁信健康微信平台有权做出独立判断并采取暂停或关闭您的账号、冻结账号内余额、关闭相应交易请求、停止提供交易信息等措施。您须对自己在网上的言论和行为承担法律责任。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">12) </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">经国家生效法律文书或行政处罚决定确认您存在违法行为，或者镁信健康微信平台有足够事实依据可以认定您存在违法或违反本协议行为的，您同意并授权镁信健康微信平台通过互联网公布您的违法、违约行为，并将该内容记入任何与您相关的信用资料和档案。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">涉及第三方网站</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您在使用镁信健康微信平台服务的过程中，可能涉及跳转至由第三方所有、控制或运营的其它网站或网页（以下称“第三方网站”）。镁信健康微信平台不能保证也没有义务保证第三方网站上的信息的真实性和有效性。您应按照第三方网站的相关协议与规则使用第三方网站。第三方网站的内容、产品、广告和其他任何信息均由您自行判断并承担风险。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">不保证</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">注册用户时，您依赖于您自己的判断进行交易，您应对您的判断承担全部责任，镁信健康微信平台、镁信健康及其股东、创建人、高级职员、董事、代理人、关联公司、母公司、子公司和雇员（以下称“镁信健康微信平台方”）不保证第三方网站内容的真实性、充分性、及时性、可靠性、完整性和有效性，并且免除任何由此引起的法律责任。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">责任限制</span></strong>
        </p>
        <p style="margin: 4px 0;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">因为镁信健康微信平台或者涉及的第三方网站的设备、系统存在缺陷或者因为计算机病毒造成的损失，镁信健康微信平台均不负责赔偿。但是，中国现行法律、法规另有规定的除外。</span></strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A"> </span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">用户过错免责。因您自身的原因导致的任何损失或责任，由您自行负责，镁信健康微信平台不承担责任，该等情形包括但不限于：</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您未按照本协议或镁信健康微信平台不时公布的任何规则进行操作导致的任何损失或责任；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">因您使用的银行卡的原因导致的损失或责任，包括您使用未经认证的银行卡或使用非您本人的银行卡或使用信用卡，您的银行卡被冻结、挂失等导致的任何损失或责任；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您向镁信健康微信平台发送的指令信息不明确、或存在歧义、不完整等导致的任何损失或责任；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">因您的决策失误、操作不当、遗忘或泄露密码、密码被他人破解、您使用的计算机系统被第三方侵入、您委托他人代理交易时他人恶意或不当操作而造成的损失；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">5)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">其他因您的原因导致的任何损失或责任。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">5.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">网站内容监测</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您确认并同意镁信健康微信平台有权不时地根据法律、法规、政府要求透露、修改或者删除必要的、合适的信息，以便更好地运营镁信健康微信平台并保护自身及镁信健康微信平台的其他合法用户。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">6.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">个人信息的使用</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">镁信健康微信平台对于您提供的、镁信健康微信平台自行收集到的关于您的个人信息，将根据您线上确认同意的、通过镁信健康微信平台因交易生成的一系列文件约定予以保护、使用或者披露，且不低于法定要求标准。该等信息包括：</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）与您实名认证相关的个人信息，包括身份证、身份证号及其他个人敏感信息<strong><span style="text-decoration:underline;">；</span></strong>
          </span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">）与配送及通知相关的您的电子邮件地址、联系电话、联系地址、邮政编码、传真号、微信号码。</span><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">[</span></em></strong><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">环球：请确认微信平台是否还收集除上述所列外的其他个人信息，如果有，请列明。]</span></em></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">&nbsp;</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您同意镁信健康微信平台在业务运营中使用您的信息，包括但不限于：</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">出于提供服务的需要在镁信健康微信平台记录您的相关信息、匹配您的订单、跟进您享受的服务情况等；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">为完成微信平台相关服务，向镁信健康微信平台的关联方或第三方合作机构（该等主体仅限于镁信健康微信平台为了完成拟向您提供的服务而合作的机构，例如与您发生实际药品购销关系的药店、为您提供线上支付服务的第三方网站运营者等）提供您的信息；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">由人工或自动程序对您的信息进行评估、分类、研究；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">使用您提供的联系方式与您联络并向您传递有关服务方面的信息；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">5)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">向您通知平台的最新功能、向您进行商业营销（您可拒绝接收该等通知）；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">6)</span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">用于配合有权机关或机构报送或调取。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您同意并授权镁信健康微信平台将您在账户注册和使用镁信健康微信平台的平台服务过程中提供、形成的信息提供给镁信健康微信平台的关联公司及与镁信健康微信平台相关的第三方合作机构，并同意镁信健康从镁信健康微信平台的关联公司及与镁信健康微信平台相关的其他服务提供者处获取您在注册、使用镁信健康微信平台相关服务期间提供、形成的信息。</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">4)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您同意上述授权时限及信息留存时间将不短于本协议期间。本协议终止后，您的身份根据本协议产生的未实现权利或未尽义务中涉及个人信息使用的、或您与镁信健康之间仍有其他协议保持有效的，您的上述授权及我们对您的个人信息的留存将在该等权利或义务继续履行的期限保持有效。</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">&nbsp;</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">7.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">索赔</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">由于您违反本协议或任何法律、法规或侵害第三方的权利，而引起第三方对镁信健康微信平台提出的任何形式的索赔、要求、诉讼等，镁信健康微信平台有权向您追偿相关损失，包括但不限于镁信健康微信平台为维护自身权益支付的全额律师费用及诉讼费用等。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">8.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">通知及送达</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您确认与本协议相关的各类文件及/或通知均应以书面形式做出，并可选用邮寄或电子任一方式进行送达。通过邮寄方式送达的，您确认在注册平台用户时提交的身份证记载的地址为有效的送达地址；通过电子方式送达的，您确认其注册平台用户时预留的传真号、电话号码、电子信箱、微信号码等为有效的送达地址。</span><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">[</span></em></strong><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">环球：代收代付服务基于药品零售进行，服务对象应为个人，不应出现企业注册证。]</span></em></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">&nbsp;</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">为便于人民法院诉讼文书及时送达，保证诉讼程序顺利进行，您确认本条第1款确定的送达地址（包括您注册平台用户时提交的身份证记载的地址，以及您注册平台用户时预留的传真号、电话号码、电子信箱、微信号码等）作为非诉阶段和争议进入民事诉讼程序后的各个阶段（包括一审、二审、再审、执行程序）相关法院送达诉讼文书的确认地址，并同意以电子方式送达。如果您提供的地址不确切，或不及时告知变更后的地址，使诉讼文书无法送达或未及时送达的，您将自行承担由此可能产生的法律后果。</span></strong>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A"> </span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">文件及/或通知递送在下列日期视为送达：</span>
        </p>
        <p class="MsoListParagraph" style="margin: 4px 0 4px 33px;background: white">
          <span style=";font-family:宋体;color:#4A4A4A">1） </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">专人递送的，以专人递送交付对方之日为有效送达；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:宋体;color:#4A4A4A">2） </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">挂号信或特快专递（付清邮资）递送的，以实际送达之日为有效送达；</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:宋体;color:#4A4A4A">3） </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">电子方式（其中包括传真、短信、邮件及微信类即时沟通工具等）递送的，以发出之时即为有效送达。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:宋体;color:#4A4A4A">4） </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您有权在任何时候更改您的联系信息，但应按本协议约定的送达方式在变更后三个工作日内向镁信健康微信平台送达变更通知。否则您应当承担由此造成的送达不能产生的法律风险及责任。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:宋体;color:#4A4A4A">5） </span><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">您的信息发生重大变动的，您应于变动发生后的三个工作日内通知镁信健康微信平台。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">9.<span style="font-variant-numeric: normal;font-weight: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">终止</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">除非镁信健康微信平台终止本协议或者您申请终止本协议且经镁信健康微信平台同意，否则本协议始终有效。镁信健康微信平台有权在不通知您的情况下在任何时间终止本协议或者限制您使用镁信健康微信平台。但镁信健康微信平台的终止行为不能免除您根据本协议或在镁信健康微信平台生成的其他协议项下的还未履行完毕的义务。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">10. </span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">适用法律和管辖</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">本协议的签订地及实际履行地为上海市徐汇区。本协议之效力、解释、变更、执行与争议解决均适用中华人民共和国法律，因本协议产生之争议，由本协议履行地上海市徐汇区人民法院管辖。</span>
        </p>
        <p style="margin: 10px 10px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">11. </span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">不可抗力</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">1)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">一旦本协议因不可抗力致使无法履行或延期履行，任何一方都将可以暂停履行本协议，但应在两个工作日内通知对方并在十五日内提交不可抗力事件的详细情况及有效证据。如果上述不可抗力的影响未能在不可抗力发生之日起三十天内消除，且协议各方未能就本协议协商一致达成变更意见，任何一方有权解除本协议，本协议自一方向其他各方发出终止通知之日起解除。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">2)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">“不可抗力”是指不能合理控制、不可预见或即使预见亦无法避免的事件，该事件使任何一方根据本协议履行其全部或部分义务已不可能。该事件包括但不限于政府行为、政策变化、地震、台风、洪水、火灾或其它天灾、战争或任何其它类似事件。</span>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">3)<span style="font-variant-numeric: normal;font-stretch: normal;font-size: 9px;line-height: normal;font-family: &#39;Times New Roman&#39;">&nbsp;&nbsp;&nbsp; </span></span>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">鉴于互联网之特殊性质，不可抗力亦包括下列影响互联网正常运行之情形：黑客攻击；电信部门技术调整导致之重大影响；因政府管制而造成之暂时关闭；病毒侵袭。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">12. </span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">附加条款</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">在镁信健康微信平台的某些部分或页面中可能存在除本协议以外的单独的附加服务条款，当这些条款存在冲突时，在该些部分和页面中附加条款优先适用。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">13. </span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">条款的独立性</span></strong>
        </p>
        <p style="margin: 4px 0 4px 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">若本协议的部分条款被认定为无效或者无法实施时，本协议中的其他条款仍然有效。</span>
        </p>
        <p style="margin: 10px 30px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">14. </span></strong><strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">签署方式</span></strong>
        </p>
        <p style="margin: 4px 0 0 4px;background: white">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#4A4A4A">本协议采用电子协议方式。您使用账户及登录密码登录镁信健康微信平台后，根据镁信健康微信平台的相关规则，在镁信健康微信平台注册页面或其他相关页面通过点击确认或类似方式签署的电子协议即视为您本人真实意愿并系为以您本人名义签署的协议，具有法律效力。您应妥善保管自己的账户密码等账户信息，您通过前述方式订立的电子协议对协议各方具有法律约束力，您不得以账户及登陆密码等账户信息被盗用或任何其他理由否认已订立的协议的效力或不按照该等协议履行相关义务。</span>
        </p>
        <p>
          &nbsp;
        </p>
        <p>
          <br/>
        </p>
        <div style="width: 100%;height: 70px;"></div>
        <div class="close" @click="agreement_Show()">
          <a href="javascript:;">我知道了</a>
        </div>
      </div>
    </div>
    <!-- 平台服务协议 -->
    <div class="agreementShow" v-show="platformServiceProtocol">
      <div class="registrationAgreement">
        <p style="text-align:center;margin:10px 0;">
          <strong><span style="font-size:16px !important;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康微信平台服务协议</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p style="text-align:right">
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">版本生效日期：2018年1月15日</span></strong>
        </p>
        <p style="text-align:right">
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">·<strong>提</strong></span><strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">示条款 </span></strong>
        </p>
        <p style="margin-bottom:4px">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">本协议双方为上海镁信健康科技有限公司（下称“镁信健康“）与申请成为镁信健康微信平台会员、享受镁信健康微信平台会员的个人（以下简称“您”）。</span>
        </p>
        <p style="margin-bottom:4px">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">欢迎您签署本《镁信健康微信平台服务协议》（下称“本协议”），享受镁信健康微信平台服务！</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">本协议为《镁信健康微信平台服务协议》修订版本，自本协议发布之日起，镁信健康微信平台各处所称“服务协议”均指本协议。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">各服务条款前所列索引关键词仅为帮助您理解该条款表达的主旨之用，不影响或限制本协议条款的含义或解释。为维护您自身权益，建议您仔细阅读各条款具体表述。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【审慎阅读】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您在申请注册流程中点击同意本协议之前，应当认真阅读本协议。<strong><span style="text-decoration:underline;">请您务必审慎阅读、充分理解各条款内容，特别是免除或者限制责任的条款、法律适用和争议解决条款。免除或者限制责任的条款将以粗体下划线标识，您应重点阅读。</span></strong>
          </span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如您对协议有任何 &nbsp;疑问，可向镁信健康微信平台客服咨询。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您使用镁信健康服务的行为将视为同意接受本协议各项条款的约束。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【签署动作】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">当您按照相关页面提示填写信息、阅读并同意本协议且完成全部账户注册程序后，即表示您已充分阅读、理解并接受本协议的全部内容，并与镁信健康达成一致，成为镁信健康微信平台“会员”。<strong><span style="text-decoration:underline;">阅读本协议的过程中，如果您不同意本协议或其中任何条款约定，您应立即停止注册程序。</span></strong>
          </span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">一、 定义</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：镁信健康微信平台经营者的单称或合称，上海镁信健康科技有限公司。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康微信平台：镁信健康公司旗下运营的微信平台（<a></a>公众号名称为“镁信健康”）。</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康微信平台服务</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：镁信健康基于互联网，以包含微信平台等在内的各种形态（包括未来技术发展出现的新的服务形态）向您提供的各项服务。服务内容包括但不限于：在您向零售药店购药时，在优惠基础上代您进行药款结算，并委托具有资质的第三方机构为您安排配送服务（如需）。。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康微信平台规则</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：包括在所有镁信健康微信平台规则频道内已经发布及后续发布的全部规则、解读、公告等内容以及各类规则、实施细则、产品流程说明、公告等。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">同一会员</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">：使用同一身份认证信息或经镁信健康排查认定多个镁信健康微信平台账户的实际控制人为同一个人的，该等账户均视为由同一会员持有。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">二、 协议范围</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">2.1 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">签约主体</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【主体资格】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您确认，在您开始注册程序使用镁信健康微信平台服务前，您应当具备中华人民共和国法律规定的与您行为相适应的民事行为能力。<strong><span style="text-decoration:underline;">若您不具备前述与您行为相适应的民事行为能力，则您及您的监护人应依照法律规定承担因此而导致的一切后果。</span></strong>
          </span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">此外，您还需确保您不是任何国家、国际组织或者地域实施的贸易限制、制裁或其他法律、规则限制的对象，否则您可能无法正常注册及使用镁信健康微信平台服务。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">2.2</span></strong><strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">补充协议</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">由于互联网高速发展，您与镁信健康签署的本协议列明的条款并不能完整罗列并覆盖您与镁信健康所有权利与义务，现有的约定也不能保证完全符合未来发展的需求。因此，镁信健康微信平台</span><a href="http://terms.alicdn.com/legal-agreement/terms/suit_bu1_taobao/suit_bu1_taobao201703241622_61002.html"
            target="_blank"><span style="font-size: 14px;font-family: 微软雅黑, sans-serif;color: windowtext">法律声明及隐私权政策</span></a><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">、知情同意书为<strong><span style="text-decoration:underline;">本协议的补充协议，与本协议不可分割且具有同等法律效力。如您使用镁信健康微信平台服务，视为您同意上述补充协议。您同意镁信健康根据未来发展的需求不断更新补充协议。</span></strong>
          </span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">三、 成为会员与使用</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康微信平台实行会员制，任何拟通过镁信健康微信平台享受会员服务的您，均应先阅读同意本协议，并通过身份验证完成相关程序后方可在镁信健康微信平台开展前述活动。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">3.1 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">会员账户说明</span></strong>
        </p>
        <p style="line-height: 21px">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【账户获得】</span></strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">当您按照相关页面提示填写信息、阅读并同意本协议且完成全部程序后，您将取得镁信健康微信平台的账户，同时成为镁信健康微信平台会员。</span>
        </p>
        <p style="line-height: 21px">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【会员资费】<span style="text-decoration:underline;">一旦您成为镁信健康微信平台会员，即视为您认可服务标明之价格；成为镁信健康微信平台会员后，会员服务即时生效。镁信健康微信平台会员的服务资费标准以镁信健康微信平台上标注的详细资费标价为准，镁信健康有权基于自身业务发展需要变更上述资费标准，但镁信健康微信平台会根据实际运营情况对不同阶段已经持续有效的会员给予续费方面的不同资费优惠，具体优惠政策以健康微信平台在相关服务页面公告的内容为准。</span></span></strong><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">[</span></em></strong><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">环球：根据《消费者权益保护法》，格式条款中的价款或者费用应以显著方式提请消费者注意。]</span></em></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如未来镁信健康向您调整收费标准，镁信健康会采取合理途径并以足够合理的期限提前通过法定程序并以本协议第八条约定的方式通知您，确保您有充分选择的权利。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【账户使用】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您有权使用您设置或确认的手机号码（以下简称“账户名称”）及您设置的密码（账户名称及密码合称“账户”）登录镁信健康微信平台。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">成为会员后，您有权利不接受镁信健康微信平台的服务，可申请取消会员服务，<strong><span style="text-decoration:underline;">但不获得会员服务费的退还。</span></strong>
          </span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您应自行负责妥善且正确地保管、使用、维护您在镁信健康微信平台申请取得的账户、账户信息及账户密码。您应对您账户信息和账户密码采取必要和有效的保密措施。非镁信健康微信平台原因致使您账户密码泄漏以及因您保管、使用、维护不当造成损失的，镁信健康微信平台无须承担与此有关的任何责任。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">由于您的镁信健康账户关联您的个人信息及镁信健康微信平台商业信息，您的镁信健康微信平台账户仅限您本人使用。未经镁信健康微信平台同意，您直接或间接授权第三方使用您镁信健康微信平台账户或获取您账户项下信息的行为无效。如镁信健康根据镁信健康微信平台规则中约定的违约认定程序及标准判断您镁信健康微信平台账户的使用可能危及您的账户安全及/或镁信健康微信平台信息安全的，镁信健康微信平台可拒绝提供相应服务或终止本协议。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【授权】</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">代扣代付授权：您使用本协议服务视为您不可撤销地授权镁信健康从您的账户（包括但不限于银行账户、微信账户、支付宝账户，视您具体选择与授权的划款方式决定）中扣划相应款项，作为委托镁信代收代付的款项，该等委托事项由您与镁信健康之间达成的《代付药款授权协议》进行约定。</span>
        </p>
        <p style="line-height: 21px">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【账户转让】<span style="text-decoration:underline;">您的账户不得以任何方式转让，否则镁信健康微信平台有权追究您的违约责任，且由此产生的一切责任均由您承担。</span></span></strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">禁止赠与、借用、租用、转让或售卖账户。否则镁信健康有权在未经通知的情况下取消转让账户、受让账户的会员服务资格，由此带来的损失由您自行承担。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【实名认证】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">作为镁信健康微信平台经营者，为使您更好地使用镁信健康微信平台的各项服务，保障您的账户安全，镁信健康可要求您按我国法律规定完成实名认证。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">3.2 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">注册信息管理</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">3.2.1 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">真实合法</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【信息真实】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">在使用镁信健康微信平台服务时，您应当按镁信健康微信平台页面的提示准确完整地提供您的信息（包括您的姓名、身份证号码及电子邮件地址、联系电话、联系地址等），以便镁信健康微信平台与您联系。<strong><span style="text-decoration:underline;">您了解并同意，您有义务保持您提供信息的真实性及有效性。</span></strong>
          </span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">3.2.2 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">更新维护</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如您提供的信息变更，您应当及时更新您提供的信息，在法律有明确规定要求镁信健康微信平台作为平台服务提供者必须对部分会员的信息进行核实的情况下，镁信健康将依法不时地对您的信息进行检查核实，您应当配合提供最新、真实、完整、有效的信息。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">3.3 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">账户安全规范</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【账户安全保管义务】</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您的账户为您自行设置并由您保管，镁信健康任何时候均不会主动要求您提供您的账户密码。因此，建议您务必保管好您的账户，并确保您每次结束时退出登录并以正确步骤离开镁信健康微信平台。</span>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">账户因您主动泄露或因您遭受他人攻击、诈骗等行为导致的损失及后果，镁信健康并不承担责任，您应通过司法、行政等救济途径向侵权行为人追偿。</span></span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【账户行为责任自负】</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">除镁信健康存在过错外，<strong><span style="text-decoration:underline;">您应对您账户项下的所有行为结果（包括但不限于在线签署各类协议、申请购买药品及服务及披露信息等）负责。</span></strong>
          </span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【日常维护须知】</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如发现任何未经授权使用您账户登录镁信健康微信平台或其他可能导致您账户遭窃、遗失的情况，建议您立即通知镁信健康。<strong><span style="text-decoration:underline;">您理解镁信健康对您的任何请求采取行动均需要合理时间，且镁信健康应您请求而采取的行动可能无法避免或阻止侵害后果的形成或扩大，除镁信健康存在法定过错外，镁信健康不承担责任。</span></strong>
          </span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">四、 镁信健康微信平台服务</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【服务概况】</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">1.</span><span style="font-size:14px;font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">完成会员后您可在镁信健康平台上享受会员优惠药价。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康提供的服务内容众多，具体您可登录镁信健康微信平台浏览。</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【交易争议处理途径】</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您在镁信健康微信平台交易过程中发生争议的，您或其他会员中任何一方均有权选择以下途径解决：</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（一）使用镁信健康微信平台提供的争议调处服务，例如客服介入；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（二）向镁信健康微信平台所在地人民法院提起诉讼。</span>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如您对调处决定不满意，您仍有权采取其他争议处理途径解决争议，但通过其他争议处理途径未取得终局决定前，您仍应先履行客服调处决定。</span></span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【责任限制】</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【不可抗力及第三方原因】<span style="text-decoration:underline;">镁信健康依照法律规定履行基础保障义务，但对于下述原因导致的合同履行障碍、履行瑕疵、履行延后或履行内容变更等情形，镁信健康并不承担相应的违约责任：</span></span></strong>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（一）因自然灾害、罢工、暴乱、战争、政府行为、司法行政命令等不可抗力因素；</span></span></strong>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（二）因电力供应故障、通讯网络故障等公共服务因素或第三人因素；</span></span></strong>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（三）在镁信健康已尽善意管理的情况下，因常规或紧急的设备与系统维护、设备与系统故障、网络信息与数据安全等因素。</span></span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康将通过依法建立相关检查监控制度尽可能保障您在镁信健康微信平台上的合法权益及良好体验。同时，<strong><span style="text-decoration:underline;">鉴于镁信健康微信平台展示的产品信息以及相关服务将依靠第三方合作机构向您提供，镁信无法逐一审查交易所涉及的商品及/或服务的质量、安全以及合法性、真实性、准确性等全部方面，对此您应谨慎判断。</span></strong>
          </span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">五、 会员信息的保护及授权</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【个人信息的保护】</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康非常重视会员个人信息（即能够独立或与其他信息结合后识别会员身份的信息）的保护，在您使用镁信健康提供的服务时，您同意镁信健康按照在镁信健康微信平台上公布的隐私权政策收集、存储、使用、披露和保护您的个人信息。镁信健康希望通过隐私权政策向您清楚地介绍镁信健康对您个人信息的处理方式，因此镁信健康建议您完整地阅读隐私权政策，以帮助您更好地保护您的隐私权。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您可以申请查看、更改或删除镁信健康微信平台已经收集到的您的个人信息，如您希望通过终止账户等方式实现撤回您对个人信息使用的授权同意，镁信健康也将予以相应支持。&nbsp;</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">六、 会员的违约及处理</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">特别约定</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【商业贿赂】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如您向镁信健康及/或其关联公司的雇员或顾问等提供实物、现金、现金等价物、劳务、旅游等价值明显超出正常商务洽谈范畴的利益，则可视为您存在商业贿赂行为。<strong><span style="text-decoration:underline;">发生上述情形的，镁信健康可立即终止与您的所有合作并向您收取违约金及/或赔偿金</span></strong>，该等金额以镁信健康因您的贿赂行为而遭受的经济损失和商誉损失作为计算依据。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【关联处理】<span style="text-decoration:underline;">如您因严重违约导致镁信健康终止本协议时，出于维护平台秩序及保护消费者权益的目的，镁信健康及/或其关联公司可对与您在其他协议项下的合作采取中止甚或终止协议的措施，并以本协议第八条约定的方式通知您。</span></span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">七、 协议的变更</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康可根据国家法律法规变化及维护交易秩序、保护消费者权益需要，不时修改本协议、补充协议。</span>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">如您对已生效的变更事项有不同意的，您应当于变更事项确定的生效之日起停止使用镁信健康微信平台服务，变更事项对您不产生效力；如您在变更事项生效后仍继续使用镁信健康微信平台服务，则视为您同意已生效的变更事项；但对于个人信息收集及使用的方式、范围、目的的变更，我们将通过在微信平台或您预留的联系方式向您推送通知的方式征求您的同意。</span></span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">八、 通知&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">8.1</span></strong><strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">有效联系方式</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您在注册成为镁信健康微信平台会员，并接受镁信健康微信平台服务时，您应该向镁信健康提供真实有效的联系方式（包括您的电子邮件地址、联系电话、联系地址等），对于联系方式发生变更的，您有义务及时更新有关信息，并保持可被联系的状态。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您在注册镁信健康微信平台会员时生成的用于登陆镁信健康微信平台接收站内信、系统消息的会员账号（包括子账号），也作为您的有效联系方式。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康将向您的上述联系方式的其中之一或其中若干向您送达各类通知，而此类通知的内容可能对您的权利义务产生重大的有利或不利影响，请您务必及时关注。</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您有权通过您注册时填写的手机号码或者电子邮箱获取您感兴趣的商品广告信息、促销优惠等商业性信息；<strong>您如果不愿意接收此类信息，您有权通过镁信健康提供的相应的退订功能进行退订。</strong></span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">8.2 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">通知的送达</span></strong>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康通过上述联系方式向您发出通知，其中以电子的方式发出的书面通知，包括但不限于在镁信健康微信平台公告，向您提供的联系电话发送手机短信，向您提供的电子邮件地址发送电子邮件，向您的账号发送信息、系统消息以及站内信信息，在发送成功后即视为送达；以纸质载体发出的书面通知，按照提供联系地址交邮后的第五个自然日即视为送达。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">对于在镁信健康微信平台上因交易活动引起的任何纠纷，您同意司法机关（包括但不限于人民法院）可以通过手机短信、电子邮件等现代通讯方式或邮寄方式向您送达法律文书（包括但不限于诉讼文书）。您指定接收法律文书的手机号码、电子邮箱等联系方式为您在镁信健康微信平台注册、更新时提供的手机号码、电子邮箱联系方式，司法机关向上述联系方式发出法律文书即视为送达。您指定的邮寄地址为您的法定联系地址或您提供的有效联系地址。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您同意司法机关可采取以上一种或多种送达方式向您送达法律文书，司法机关采取多种方式向您送达法律文书，送达时间以上述送达方式中最先送达的为准。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您同意上述送达方式适用于各个司法程序阶段。如进入诉讼程序的，包括但不限于一审、二审、再审、执行以及督促程序等。</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">你应当保证所提供的联系方式是准确、有效的，并进行实时更新。如果因提供的联系方式不确切，或不及时告知变更后的联系方式，使法律文书无法送达或未及时送达，由您自行承担由此可能产生的法律后果。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">九、 协议的终止</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">9.1 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">终止的情形</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【镁信健康发起的终止】</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">出现以下情况时，镁信健康可以本协议第八条的所列的方式通知您终止本协议：</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（一）您违反本协议约定，镁信健康依据违约条款终止本协议的；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（二）除上述情形外，因您多次违反镁信健康微信平台规则相关规定且情节严重，镁信健康依据镁信健康微信平台规则对您的账户予以查封的；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（三）您的账户被镁信健康依据本协议回收的；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（四）其它应当终止服务的情况。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【用户发起的终止】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">您可以向镁信健康微信平台申请终止本协议，经镁信健康微信平台同意可终止。</span><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">[</span></em></strong><strong><em><span style=";font-family:黑体;color:#4A4A4A;background:yellow;background:yellow">环球：与平台注册协议保持一致。]</span></em></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">9.2 </span></strong><strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">协议终止后的处理</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【会员信息披露】<span style="text-decoration:underline;">本协议终止后，除法律有明确规定外，镁信健康无义务向您或您指定的第三方披露您账户中的任何信息。</span></span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【镁信健康权利】</span></strong><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">本协议终止后，镁信健康仍享有下列权利：</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（一）仅在记录交易或系统维护所需的限度内，继续保存您留存于镁信健康微信平台的本协议第五条所列的各类信息；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">（二）对于您过往的违约行为，镁信健康仍可依据本协议向您追究违约责任。</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">十、 法律适用、管辖与其他</span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【法律适用】<span style="text-decoration:underline;">本协议之订立、生效、解释、修订、补充、终止、执行与争议解决均适用中华人民共和国大陆地区法律；如法律无相关规定的，参照商业惯例及/或行业惯例。</span></span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【管辖】<span style="text-decoration:underline;">您因使用镁信健康微信平台服务所产生及与镁信健康微信平台服务有关的争议，由镁信健康与您协商解决。协商不成时，任何一方均可向镁信健康微信平台所在地有管辖权的人民法院提起诉讼。</span></span></strong>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">【可分性】</span></strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">本协议任一条款被视为废止、无效或不可执行，该条应视为可分的且并不影响本协议其余条款的有效性及可执行性。</span>
        </p>
        <p style="margin: 10px 0;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">十一、签署方式</span></strong>
        </p>
        <p style="margin-top: 4px;background: white">
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">本协议采用电子合同方式。您使用账户及登录密码登录镁信健康微信平台后，根据镁信健康微信平台的相关规则，在镁信健康微信平台注册页面或其他相关页面通过点击确认或类似方式签署的电子合同即视为您本人真实意愿并系为以您本人名义签署的协议，具有法律效力。您应妥善保管自己的账户密码等账户信息，您通过前述方式订立的电子合同对合同各方具有法律约束力，您不得以账户及登陆密码等账户信息被盗用或任何其他理由否认已订立的协议的效力或不按照该等协议履行相关义务。</span></strong>
        </p>
        <p>
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span></strong>
        </p>
        <p>
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">十二、协议变更</span></strong>
        </p>
        <p>
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康有权随时对服务条款进行修改，一旦服务条款发生变更和修改。镁信健康将在相关页面上提示修改的内容；如果您不同意本协议的修改，可以取消已经获取的服务并停止使用；如果您继续使用镁信健康提供的服务，则视为您已经接受本协议的全部修改。</span></strong>
        </p>
        <p>
          <strong><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">镁信健康对本协议一旦进行修改，将在页面上公示修改的内容。一经公布即视为通知您。</span></strong>
        </p>
        <p>
          <br/>
        </p>
        <div style="width: 100%;height: 70px;"></div>
        <div class="close" @click="platformService()">
          <a href="javascript:;">我知道了</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Api from '@/api/member';
  import {
    Group,
    XInput,
    Cell,
    Selector,
    XButton,
    Flexbox,
    FlexboxItem,
    AlertModule
  } from 'vux';
  export default {
    components: {
      Group,
      XInput,
      Cell,
      Selector,
      XButton,
      Flexbox,
      FlexboxItem,
      AlertModule
    },
    data() {
      return {
        // list: ['男', '女'],
        phoneNo: '',
        name: '',
        idNum: '',
        // sex: ''
        readProtocol: false,
        unreadProtocol: true,
        agreementShow: false,
        platformServiceProtocol: false,
      }
    },
    methods: {
      next() {
        // if (this.sex == '男') {
        //   this.sex = 'm'
        // } else if (this.sex == '女') {
        //   this.sex = 'f'
        // }
        if (!this.name) {
          this.$vux.toast.text("请填写姓名");
          return false;
        } else if (!this.idNum) {
          this.$vux.toast.text("请填写身份证号");
          return false;
        } else if (!this.readProtocol) {
          this.$vux.toast.text("请阅读协议");
          return false;
        }
        new Promise((resolve, reject) => {
          Api.update(this.name, this.idNum)
            .then(response => {
              this.showPlugin();
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
      showPlugin() {
        let that = this;
        this.$vux.alert.show({
          title: '恭喜！',
          content: '会员信息添加成功！',
          onShow() {},
          onHide() {
            localStorage.setItem('orderType', '02');
            that.$router.push({
              path: "/buyVipCard",
            });
          }
        })
      },
      info() {
        new Promise((resolve, reject) => {
          Api.info()
            .then(response => {
              this.name = response.result.name;
              this.idNum = response.result.idNum;
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
      // 注册协议
      agreement_Show() {
        if (this.agreementShow) {
          this.agreementShow = false;
        } else {
          this.agreementShow = true;
        }
      },
      // 平台服务协议
      platformService() {
        if (this.platformServiceProtocol) {
          this.platformServiceProtocol = false;
        } else {
          this.platformServiceProtocol = true;
        }
      },
      // 是否阅读协议
      setReadProtocol() {
        if (this.readProtocol) {
          this.readProtocol = false;
          this.unreadProtocol = true;
        }
      },
      setUnreadProtocol() {
        if (this.unreadProtocol) {
          this.unreadProtocol = false;
          this.readProtocol = true;
        }
      },
      // 判断是否是会员
      isVip() {
        new Promise((resolve, reject) => {
          Api.isVip()
            .then(response => {
              if (response.result) {
                this.isVipShowPlugin();
              }
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
      isVipShowPlugin() {
        let that = this;
        that.$vux.confirm.show({
          title: '亲',
          content: '您已经是尊贵的会员了',
          onCancel() {
            WeixinJSBridge.call('closeWindow');
          },
          onConfirm() {
            that.$router.push('/myAccount');
          }
        })
      },
    },
    beforeCreate() {
      new Promise((resolve, reject) => {
        Api.profile()
          .then(response => {
            this.phoneNo = response.result.phoneNo;
          })
          .catch(error => {
            reject(error);
          });
      });
    },
    mounted() {
      localStorage.setItem('vipCardProductId', '2');
      this.isVip();
      this.info();
    }
  }
</script>

<style lang="less" scoped>
  .label {
    color: #409eff;
    font-size: 16px;
  }
  .btn {
    margin-top: 50%;
    margin-bottom: 20%;
  }
  /* 协议弹窗 */
  .agreement {
    padding: 10px 4%;
  }
  .agreement a {
    color: #007aff;
    margin-left: 4px;
  }
  .agreementShow {
    width: 100%;
    height: auto;
    background-color: #ffffff;
    z-index: 999;
    position: absolute;
    top: 0;
    left: 0;
  }
  .registrationAgreement {
    width: 96%;
    padding: 0 2%;
  }
  .close {
    height: 50px;
    width: 80%;
    margin: 0 auto;
    background-color: #007aff;
    border-radius: 25px;
    position: fixed;
    bottom: 20px;
    left: 10%;
    line-height: 50px;
    text-align: center;
    font-size: 20px;
  }
  .close a {
    color: #ffffff;
  }
  .agreementShow p {
    text-align: justify;
    font-size: 12px;
  }
  .agreementShow p span {
    font-size: 12px !important;
  }
</style>
