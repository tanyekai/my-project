<template>
  <div>
    <group gutter='0%' style='padding:10px'>
      <cell title="用户银行卡信息" style='color:#3385ff;font-size:18px'>
        <svg class="icon" slot='icon' style='color:#409eff'>
          <use xlink:href="#icon-yinhangqia"></use>
        </svg>
      </cell>
      <!-- 姓名 -->
      <x-input v-model='userName' text-align='right' placeholder-align='right' name="username" placeholder="请输入姓名" is-type="china-name">
        <span slot='label' style='color:red'>* </span>
        <span slot='label'>姓名</span>
      </x-input>
      <!-- 身份证号码 -->
      <x-input v-model='idCardNo' text-align='right' placeholder-align='right' name="idCard" placeholder="请输入身份证号码" :min="18" :max="18">
        <span slot='label' style='color:red'>* </span>
        <span slot='label'>身份证</span>
      </x-input>
      <!-- 开户行 -->
      <cell v-model='bankName ' @click.native='show=true' is-link>
        <span slot='title' style='color:red'>* </span>
        <span slot='title'>开户行</span>
      </cell>
      <actionsheet v-model="show" :menus="bankList" theme="android" @on-click-menu="checkedBank"></actionsheet>
      <!-- <popup-radio v-model='bankName' title="开户行" :options="options">
      </popup-radio> -->
      <!-- <selector title='开户行' :options='options' v-model='bankName'></selector> -->
      <!-- 卡号 -->
      <x-input v-model='bankCard' text-align='right' placeholder-align='right' keyboard="number" type="text" placeholder="必须为借记卡卡号">
        <span slot='label' style='color:red'>* </span>
        <span slot='label'>卡号</span>
      </x-input>
      <!-- 银行预留手机号 -->
      <x-input v-model='mobile' text-align='right' placeholder-align='right' placeholder="请输入手机号码" keyboard="number" is-type="china-mobile">
        <span slot='label' style='color:red'>* </span>
        <span slot='label'>银行预留手机号</span>
      </x-input>
      <!-- 验证码 -->
      <!-- <x-input title="验证码" text-align='right' placeholder-align='right' class="weui-cell_vcode">
        <img slot="right" class="weui-vcode-img" src="https://i.loli.net/2017/09/18/59bf7f32425d5.jpg">
      </x-input> -->
      <!-- 短信验证码 -->
      <x-input v-model="validateCode" title='短信验证码' class="weui-vcode" :max='maxCode' placeholder="请输入短信验证码" keyboard="number">
        <!-- <span slot='label' style='color:red'>* </span>
        <span slot='label'>短信验证码</span> -->
      </x-input>
      <button @click="getSms" class='btn' ref='color'>{{word}}</button>
      <!-- 同意按钮 -->
      <!-- <x-switch v-model='agree' title='我已阅读'></x-switch> -->
      <!-- 条款 -->
      <!-- <router-link to="/index">
        <cell title="" inline-desc='请阅读并知悉《用户支持服务条款》'></cell>
      </router-link> -->

    </group>
    <!-- 按钮 -->
    <flexbox style='margin-top:10%'>
      <flexbox-item style='padding:0 2%'>
        <x-button @click.native='next' style="background-color: #409eff;color:#fff;">保存</x-button>
      </flexbox-item>
    </flexbox>


  </div>
</template>


<script>
  import Api from "@/api/bankCard";
  import Api_dict from "@/api/dict";
  import Api_member from "@/api/member";
  import {
    Group,
    Cell,
    XInput,
    PopupRadio,
    XSwitch,
    Flexbox,
    FlexboxItem,
    XButton,
    Toast,
    AlertModule,
    Selector,
    Actionsheet
  } from "vux";
  export default {
    components: {
      Group,
      Cell,
      XInput,
      PopupRadio,
      XSwitch,
      Flexbox,
      FlexboxItem,
      XButton,
      Toast,
      AlertModule,
      Selector,
      Actionsheet
    },
    data() {
      return {
        word: '获取验证码',
        maxCode: 6,
        bankList: [],
        userName: '',
        idCardNo: '',
        mobile: '',
        bankName: '',
        bankCode: '', // 传给后台的银行码
        bankCard: '',
        agree: '',
        validateCode: '',
        show: false,
      };
    },

    mounted() {
      this.info();
      this.dictCodeQuery();
    },

    methods: {
      //  请求：上传银行卡信息，获取短信验证码
      saveBankInfo() {
        new Promise((resolve, reject) => {
          Api.bankBind(
              this.userName,
              this.idCardNo,
              this.mobile,
              this.bankName,
              this.bankCard
            )
            .then(response => {
              //  按钮状态变化
              this.$refs.color.style.backgroundColor = "#f91";
              let that = this,
                time = 60;
              var sendTimer = setInterval(function () {
                that.isOvertime = true;
                time--;
                that.word = time + " 后重新发送";
                if (time < 0) {
                  that.isOvertime = false;
                  clearInterval(sendTimer);
                  that.word = "获取验证码";
                  that.$refs.color.style.backgroundColor = "#409eff";
                }
              }, 1000);
              if (this.isOvertime) {
                this.$vux.toast.text("别急，正在发送中");
                return false;
              }
            })
            .catch(error => {
              //  error : 该用户已绑卡
              reject(error);
              //  已经绑卡提示
              this.errorShowPlugin(error);

            });
        });
      },
      //  请求：短信验证
      checkBindSms() {
        new Promise((resolve, reject) => {
          Api.checkBindSms(
              this.validateCode,
              this.bankCard,
              this.bankName,
              this.bankCode
            )
            .then(response => {
              this.showPlugin("绑卡成功！");
            })
            .catch(error => {
              reject(error);
              this.errorShowPlugin(error);
            });
        });
      },
      //  点击获取验证码按钮发送请求获取验证码,做请求参数非空判断
      getSms() {
        if (!this.userName) {
          this.$vux.toast.text("请输入姓名");
        } else if (!this.idCardNo) {
          this.$vux.toast.text("请输入身份证号码");
        } else if (!this.bankName) {
          this.$vux.toast.text("请选择开户行");
        } else if (!this.bankCard) {
          this.$vux.toast.text("请输入卡号");
        } else if (!this.mobile) {
          this.$vux.toast.text("请输入银行预留手机号");
        } else {
          //  点击获取短信验证码，这个请求也校验了银行卡信息
          //  bug:这里已绑卡的请求返回的也是true
          this.saveBankInfo();


        }
      },
      //  点击发送请求做短信验证,按钮验证
      next() {
        if (!this.validateCode) {
          this.$vux.toast.text("请输入短信验证码");
        } else if (this.validateCode.length != 6) {
          this.$vux.toast.text("短信验证码是6位数字");
        }
        //  else if (!this.agree) {
        //   this.$vux.toast.text("请阅读并知悉《用户支持服务条款》");
        // } 
        else {
          this.checkBindSms();
        }
      },
      //  绑卡成功提示
      showPlugin(info) {
        let self = this;
        this.$vux.alert.show({
          title: '恭喜！',
          content: info,
          onShow() {},
          onHide() {
            // alert("开始判断！");
            // 判断来源是订单详情就直接带参跳到支付页面
            if (self.$route.query.source == 'orderDetails') {
              self.$router.push({
                path: "/orderBankPay",
                query: {
                  index:0,
                  orderType: self.$route.query.orderType,
                  orderNo: self.$route.query.orderNo,
                  actualAmount: self.$route.query.actualAmount
                }
              });
            } else {
              self.$router.push('/myBankCard');
            }
          }
        })
      },
      //  绑卡错误提示
      errorShowPlugin(info) {
        let self = this;
        this.$vux.alert.show({
          title: '抱歉',
          content: info,
          onShow() {},
          onHide() {
            // self.$router.push('/myBankCard');
          }
        })
      },
      // 获取选中银行的名称和编码
      checkedBank(key) {
        this.bankName = this.bankList[key];
        this.bankCode = key;
      },

      // 获取银行列表数据
      dictCodeQuery() {
        new Promise((resolve, reject) => {
          Api_dict.dictCodeQuery(
              'YB_BANK'
            )
            .then(response => {
              // var bankObj = response.result
              // for (var key in bankObj) {
              //   this.options.push(bankObj[key]);
              //   console.log(bankObj[key]);
              // }
              this.bankList = response.result
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },

      // 带出姓名和身份证号
      info() {
        new Promise((resolve, reject) => {
          Api_member.info()
            .then(response => {
              this.userName = response.result.name;
              this.idCardNo = response.result.idNum;
              this.mobile = response.result.phoneNo;
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
    }
  };

</script>

<style lang="less">
  @import "~vux/src/styles/1px.less";
  .btn {
    position: absolute;
    z-index: 0;
    top: 88%;
    right: 4px;
    background-color: #409eff;
    display: block;
    margin-left: auto;
    margin-right: auto;
    padding-left: 14px;
    padding-right: 14px;
    box-sizing: border-box;
    font-size: 14px;
    text-align: center;
    text-decoration: none;
    color: #FFFFFF;
    line-height: 2.33333333;
    border-radius: 5px;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    overflow: hidden;
    border: none;
  }

  .btn:focus {
    outline: 0;
  }

  .weui-cell_select .weui-select {
    padding-left: 58% !important;
  } // 银行列表弹出层加滚动条,限制高度
  .weui-skin_android .weui-actionsheet__menu {
    height: 388px;
    overflow: auto;
  } // 银行列表弹出层高度控制
  .weui-skin_android .weui-actionsheet {
    top: 42% !important;
  }

  .weui-cell__ft {
    color: #000 !important;
  }

</style>
