<template>
  <div>
    <group gutter='0%'>
      <cell title="新增地址" style='color:#3385ff;font-size:18px'>
        <svg class="icon" slot='icon' style='color:#409eff'>
          <use xlink:href="#icon-dizhi1"></use>
        </svg>
      </cell>
      <!-- 姓名 -->
      <x-input title="收货人" name="username" text-align='right' placeholder-align='right' placeholder="请输入收货人姓名" is-type="china-name"
        v-model="consigneeName"></x-input>
      <!-- 手机号 -->
      <x-input title="手机" name="mobile" type='number' text-align='right' placeholder-align='right' placeholder="请输入手机号码" keyboard="number"
        v-model="mobile" is-type="china-mobile" :min="11" :max="11"></x-input>
      <!-- 地址 -->
      <x-address style="display:block;" title="地址" :list="test" @on-shadow-change="onShadowChange" placeholder="请选择地址" inline-desc=""
        :show.sync="showAddress"></x-address>
      <!-- 详细地址 -->
      <x-textarea style="display:block;" :show.sync="showAddress" title="详细地址" placeholder='请输入详细地址' v-model="detailedAddress"></x-textarea>
      <!-- 同意按钮 -->
      <x-switch title="设为默认地址" :value-map="['2', '1']" v-model="defaultAddress" @on-change="clickingSwitch"></x-switch>
      <!-- 按钮 -->
      <flexbox style='margin-top:25%;margin-bottom:30%'>
        <flexbox-item style='padding:0 4%'>
          <x-button @click.native="newAddress()" style="background-color: #409eff;color:#fff;">保存</x-button>
        </flexbox-item>
      </flexbox>
    </group>

    <!-- toast提醒 -->
    <toast v-model="showPositionValue" type="text" :time="1500" is-show-mask :text="text" :position="position" style="width:60%;"></toast>
  </div>
</template>


<script>
  import Api from "@/api/thePurchase";
  import Api_member from "@/api/member";
  import {
    Group,
    Cell,
    XInput,
    PopupRadio,
    XSwitch,
    Flexbox,
    FlexboxItem,
    XButton,
    XAddress,
    XTextarea,
    Toast,
    base64
    // ChinaAddressV4Data,
    // Value2nameFilter as value2name
  } from "vux";
  export default {
    components: {
      Group,
      Cell,
      XInput,
      PopupRadio,
      XSwitch,
      Flexbox,
      FlexboxItem,
      XButton,
      XAddress,
      XTextarea,
      Toast
    },
    data() {
      return {
        showAddress: false,
        test: [],
        consigneeName: "",
        mobile: "",
        provincialAddress: "",
        provinceCode: "",
        cityCode: "",
        districtCode: "",
        detailedAddress: "",
        defaultAddress: "2",
        position: "",
        text: "",
        showPositionValue: false,
        type: this.$route.query.type,
        provincial: '',
        city: '',
        district: '',
      };
    },
    methods: {
      onShadowChange(ids, names) {
        this.provincialAddress = ids;
        this.provinceCode = this.provincialAddress[0];
        this.cityCode = this.provincialAddress[1];
        this.districtCode = this.provincialAddress[2];
        this.provincial = base64.encode(names[0]);
        this.city = base64.encode(names[1]);
        this.district = base64.encode(names[2]);
      },

      clickingSwitch() {
        console.log(this.defaultAddress);
      },
      showPosition(position) {
        this.position = position;
        this.showPositionValue = true;
      },
      // 查询中国所有省市区
      inquiryProvince() {
        new Promise((resolve, reject) => {
          Api.chinaQuery()
            .then(response => {
              // debugger;
              // console.log("resolve", response);
              this.test = response.result;
            })
            .catch(error => {
              reject(error);
            });
        });
      },
      //新增地址
      newAddress() {
        if (this.consigneeName == "") {
          this.text = "收货人姓名不能为空";
          this.showPosition("top");
          return;
        }
        if (this.mobile == "") {
          this.text = "手机号不能为空";
          this.showPosition("top");
          return;
        }
        if (this.provincialAddress == typeof string) {
          this.text = "地址不能为空";
          this.showPosition("top");
          return;
        }
        if (this.detailedAddress == "") {
          this.text = "详细地址不能为空";
          this.showPosition("top");
          return;
        }
        // console.log(this.provincialAddress);
        new Promise((resolve, reject) => {
          Api.newAddress(
              this.consigneeName,
              this.mobile,
              this.provinceCode,
              this.cityCode,
              this.districtCode,
              this.detailedAddress,
              this.defaultAddress,
            )
            .then(response => {
              // alert(response.result.id);
              // console.log(response.result);
              if (this.type == 'deliveryToHome') {
                this.$router.push({
                  path: "/deliveryToHome",
                  query: {
                    addressId: response.result.id,
                    provincial: this.provincial,
                    city: this.city,
                    district: this.district
                  }
                });
              } else {
                this.showPlugin('恭喜！', '新增地址成功！', '/address');
              }

            })
            .catch(error => {
              reject(error);
            });
        });
      },

      showPlugin(title, content, path) {
        let self = this;
        this.$vux.alert.show({
          title: title,
          content: content,
          onShow() {},
          onHide() {
            self.$router.push(path);
          }
        });
      },

      // 带出姓名和身份证号
      info() {
        new Promise((resolve, reject) => {
          Api_member.info()
            .then(response => {
              this.consigneeName = response.result.name;
              this.mobile = response.result.phoneNo;
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      }
    },
    mounted() {
      this.info();
      this.inquiryProvince();
    }
  };

</script>

<style lang="less">
  @import "~vux/src/styles/1px.less";
  .vux-toast-top {
    width: 11em !important;
  }

</style>
