<template>
  <scroller lock-x>
    <div>
      <!-- 收获地址选择 -->
      <group gutter='0%' style='padding:10px'>
        <cell title='收货地址' is-link value='选择地址' :link="{path:'/address?type=deliveryToHome'}" style='font-weight:600'>
          <svg class='icon' slot='icon'>
            <use xlink:href="#icon-dizhi1"></use>
          </svg>
        </cell>
        <cell>
          <p slot='inline-desc'>收件人：{{ this.addressName }}</p>
          <p slot='inline-desc' class='limitOneLine'>收货地址：{{ this.provincial + this.city + this.district + this.addressFullAddress }}</p>
          <p slot='inline-desc'>联系电话：{{ this.addressMobile }}</p>
        </cell>
      </group>

      <!-- 上传处方 -->
      <group gutter='-2%' style='padding:10px'>

        <cell title="上传处方" value='请上传三日内有效处方，详见样张' style='font-weight:700'>
          <svg class='icon' slot='icon'>
            <use xlink:href="#icon-dingdan-blue"></use>
          </svg>
        </cell>
        <div class='uploader'>
          <!-- 上传处方 -->
          <div v-for='(item ,index ) in imgs' :key="(item,index)" class='uploadImg'>
            <img :src="item">
            <span @click='delete_img(index)'>
              <svg class="icon" slot='icon' style='position:absolute;font-size:40px;right:10%;bottom:33%'>
                <use xlink:href="#icon-delete2"></use>
              </svg>
            </span>
          </div>
          <!-- 添加按钮 -->
          <div class='addBtn'>
            <span class='addIcon'>
              <img src="../assets/add_img.png">
            </span>
            <input @change='add_img' type="file" accept="image/*">
          </div>
          <!-- 样张 -->
          <div class='case' @click='cfCode=true'>
            <span class='desc'>处方样张</span>
            <img src="../assets/cf.png" alt="" @click="showImg()">
          </div>
        </div>
      </group>
      <div>
        <x-dialog v-model="cfCode" :hide-on-blur="true">
          <div>
            <div style='padding:0px;padding-bottom:0px'>
              <img src='../assets/cf.png' alt="" style='width:100%;height:100%;'>
            </div>
          </div>
        </x-dialog>
      </div>

      <!-- 患者信息 -->
      <group gutter='-2%' style='padding:10px'>
        <cell title="患者信息" style='font-weight:700'>
          <svg class="icon" slot='icon'>
            <use xlink:href="#icon-huanzhe3"></use>
          </svg>
        </cell>
        <cell>
          <p slot='inline-desc'>姓名：{{ name }}</p>
          <p slot='inline-desc'>身份证：{{ idNum}}</p>
        </cell>
      </group>

      <group gutter='-2%' style='padding:10px'>

        <datetime title='期望送药时间' v-model="expectFreightDate" :start-date='startDate' :end-date='endDate'>
          <span slot='title'>
            <svg class="icon" slot='icon'>
              <use xlink:href="#icon-shijian-copy-copy"></use>
            </svg>
            <span style='font-weight:700'>期望送药日期</span>
          </span>
        </datetime>
        <x-textarea title='备注' style="display:block" v-model='remark' placeholder='请填写药品的名称、数量等明细信息'></x-textarea>

      </group>


      <flexbox style='margin-top:4%;margin-bottom:10%'>
        <flexbox-item style='padding:0 2%'>
          <x-button style='background-color: #409eff;color:#fff;' @click.native='submitOrder()'>提交需求</x-button>
        </flexbox-item>
      </flexbox>

      <!-- <divider style='padding:16px;color:#969696'>创新医疗支付专家</divider> -->
    </div>
  </scroller>

</template>


<script>
  import Api_upload from "@/api/upload"
  import Api_order from "@/api/order"
  import Api_patient from "@/api/patient"
  import Api_member from '@/api/member'
  import Api_address from '@/api/address'
  import {
    Group,
    Cell,
    XInput,
    PopupRadio,
    XSwitch,
    Flexbox,
    FlexboxItem,
    XButton,
    CellFormPreview,
    FormPreview,
    Datetime,
    XTextarea,
    base64,
    Scroller,
    XDialog,
    Divider
  } from "vux";
  import {
    setTimeout
  } from 'timers';
  export default {
    components: {
      Group,
      Cell,
      XInput,
      PopupRadio,
      XSwitch,
      Flexbox,
      FlexboxItem,
      XButton,
      CellFormPreview,
      FormPreview,
      Datetime,
      XTextarea,
      Scroller,
      XDialog,
      Divider
    },
    data() {
      return {
        // 处方上传
        show: false,
        imgs: [],
        imgArr: [],
        userId: "0",
        // 处方：04，头像：03，身份证：00
        datumCode: "04",
        // 患者：01，申请人：00
        userType: "01",
        name: '',
        idNum: '',
        //  submitOrder 参数
        expectFreightDate: '',
        prescriptionId: '',
        remark: '',
        addressId: this.$route.query.addressId,
        addressName: '',
        addressMobile: '',
        addressFullAddress: '',
        imageId: '',
        provincial: '',
        city: '',
        district: '',
        cfCode: false,
        // 2015-11-11 日期控件参数设置  
        startDate: '',
        endDate: '',
        // disabled: false
      };
    },
    methods: {
      //  submitOrder 提交订单
      submitOrder() {
        // this.disabled = true;
        // setTimeout(function () {
        //   this.disabled = false;
        // }, 2000)
        alert(this.addressId);
        alert(this.prescriptionId);
        alert(this.expectFreightDate);
        alert(this.remark);
        if (!this.addressId) {
          this.$vux.toast.text("请选择收货地址");
        } else if (!this.expectFreightDate) {
          this.$vux.toast.text("请选择期望送药时间");
        } else if (!this.prescriptionId) {
          this.$vux.toast.text("请上传三日内有效处方");
        } else {
          new Promise((resolve, reject) => {
            Api_order.submitOrder(this.addressId, this.prescriptionId, this.expectFreightDate, this.remark)
              .then(response => {
                this.orderSuccess('恭喜！', '提交成功！', '/myOrder');
              })
              .catch(error => {
                this.$vux.toast.text(error);
                reject(error);
              });
          });
        }
      },

      //  通过addressId查询地址信息
      query() {
        new Promise((resolve, reject) => {
          Api_address.query(this.addressId)
            .then(response => {
              console.log(response.result[0].receiver);
              this.addressName = response.result[0].receiver
              this.addressMobile = response.result[0].mobile
              this.addressFullAddress = response.result[0].fullAddress
              // this.$route.go(0);
            })
            .catch(error => {
              reject(error)
            })
        })
      },
      //  页面加载渲染患者信息
      patientInfo() {
        new Promise((resolve, reject) => {
          Api_patient.queryPatient()
            .then(response => {
              if (response.result.length == 0) {
                this.noPatientInfo();
              } else {
                this.name = response.result[0].name;
                this.idNum = response.result[0].idNum;
              }
            })
            .catch(error => {
              reject(error);
            });
        });
      },
      delete_img(item) {
        this.imgs.splice(item, 1);
        this.imgArr.splice(item, 1);
        new Promise((resolve, reject) => {
          Api_upload.delete(this.imageId)
            .then(response => {})
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });

      },

      add_img(event) {
        this.$vux.loading.show({
          text: 'Loading'
        })
        setTimeout(() => {
          this.$vux.loading.hide()
        }, 1000)
        // if (!!window.navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)) {
        //   // iOS
        //   // alert("ios");
        //   var img = event.target.files[0];
        //   var that = this;
        //   that.imgArr.push(img);
        //   var file = that.imgArr[0];
        //   var param = new FormData(); // 创建form对象
        //   param.append("file", file, file.name); // 通过append向form对象添加数据
        //   // param.append('chunk', '0') // 添加form表单中其他数据
        //   // console.log(param.get('file')) // FormData私有类对象，访问不到，可以通过get判断值是否传进去
        //   new Promise((resolve, reject) => {
        //     Api.upload(param, that.datumCode, that.userType)
        //       .then(response => {
        //         alert('图片上传成功');
        //         // this.imageId = response.result[0].imageId;
        //         // this.prescriptionId = response.result[0].id;
        //       })
        //       .catch(error => {
        //         alert("图片上传失败");
        //         reject(error);
        //       });
        //   });
        //   return;
        // } else {
        // alert("安卓");
        var reader = new FileReader();
        var img = event.target.files[0];
        reader.readAsDataURL(img);
        var that = this;
        that.imgArr.push(img);
        reader.onloadend = function () {
          // reader.result是base64
          that.imgs.push(reader.result);
          // that.submit();
          // var self = this;
          var file = that.imgArr[0];
          var param = new FormData(); // 创建form对象
          param.append("file", file, file.name); // 通过append向form对象添加数据
          // param.append('chunk', '0') // 添加form表单中其他数据
          // console.log(param.get('file')) // FormData私有类对象，访问不到，可以通过get判断值是否传进去
          new Promise((resolve, reject) => {
            Api_upload.upload(param, that.datumCode, that.userType)
              .then(response => {
                that.imageId = response.result[0].imageId;
                that.prescriptionId = response.result[0].prescriptionId;
                // that.$vux.loading.hide();
              })
              .catch(error => {
                this.$vux.toast.text(error);
                reject(error);
              });
          });
        };

        // }

      },

      isMember() {
        new Promise((resolve, reject) => {
          Api_member.isVip()
            .then(response => {
              if (response.result) {
                this.patientInfo();
              } else {
                sessionStorage.setItem('orderSource', 'deliveryToHome');
                this.showPlugin('亲', "您还不是会员，是否去购买会员？", '/addMember');
              }
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },


      //  点击放大图片
      showImg() {
        this.show = true;
      },
      closeImg() {
        this.show = false;
      },
      //  图片上传成功提示
      showPlugin(title, content, path) {
        let self = this;
        this.$vux.confirm.show({
          title: title,
          content: content,
          onConfirm() {
            self.$router.push(path);
          },
          onCancel() {
            WeixinJSBridge.call('closeWindow');
          }
        });
      },

      // 下单成功提示
      orderSuccess(title, content, path) {
        let self = this;
        this.$vux.alert.show({
          title: title,
          content: content,
          onShow() {},
          onHide() {
            self.$router.push(path);
          }
        });
      },
      //  未查询到患者信息提示
      noPatientInfo() {
        sessionStorage.setItem('orderSource', 'deliveryToHome');
        let self = this;
        this.$vux.confirm.show({
          title: "亲",
          content: "未查询到患者信息，请先添加患者信息！",
          onConfirm() {
            self.$router.push("/addBeneficiary");
          },
          onCancel() {
            WeixinJSBridge.call('closeWindow');
          }
        });
      },

      // 获取当前日期
      getCurrentDate() {
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        this.startDate = year + '-' + month + '-' + day;
        this.endDate = year + '-' + (month + 1) + '-' + day
      },
    },

    updated() {
      if (this.imgs.length == 1) {
        document.getElementsByClassName('addBtn')[0].style.display = 'none'
      } else {
        document.getElementsByClassName('addBtn')[0].style.display = 'inline-block'
      }
    },

    mounted() {
      this.isMember();
      this.getCurrentDate();

      if (this.addressId) {
        // alert(this.addressId);
        this.query();
        this.provincial = base64.decode(this.$route.query.provincial);
        this.city = base64.decode(this.$route.query.city);
        this.district = base64.decode(this.$route.query.district);
      } else {
        // alert("2");
      }



    },
  };

</script>

<style lang="less" scoped>
  .slide {
    padding: 0 20px;
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.5s cubic-bezier(0, 1, 0, 1) -0.1s;
  }

  .animate {
    max-height: 9999px;
    transition-timing-function: cubic-bezier(0.5, 0, 1, 0);
    transition-delay: 0s;
  }

  input {
    font-size: 0;
    /* 为了去掉‘未选择任何文件’这几个字，也可以随便弄到哪里*/
  }
  /* 注意不是直接input > input[type=button] 哦*/

  input::-webkit-file-upload-button {
    background: #efeeee;
    color: #333;
    border: 0;
    padding: 40px 70px;
    border-radius: 5px;
    font-size: 12px;
    box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.1), 0 0 10px rgba(0, 0, 0, 0.12);
  }

  .uploader {
    height: auto;
    padding-top: 4px;
    padding-bottom: 34px;
    align-items: center;
    padding-right: 40%;
    position: relative;
  }

  .uploader .uploadImg {
    width: 80px;
    height: 80px;
    margin-left: 10px;
    margin-right: 10px;
    position: relative;
    overflow: hidden;
    display: inline-block;
    box-shadow: 0px 1px 10px #888;
  }

  .uploader .uploadImg img {
    width: 100%;
    height: 100%;
  }

  .uploader .uploadImg span {
    position: absolute;
    width: 50px;
    height: 50px;
    right: 3px;
    bottom: 4px;
  }

  .addBtn {
    width: 80px;
    height: 80px;
    border: 1px solid #e1e1e1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    position: relative;
    margin-left: 10px;
  }

  .addIcon {
    position: absolute;
    top: 20px;
    left: 20px;
  }

  .addBtn input {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: 99999;
    opacity: 0;
  }

  .case {
    position: absolute;
    right: 4%;
    top: 1%;
    height: 86px;
    width: 76px;
    box-shadow: 0px 1px 10px #888;
    /* border:1px solid #000; */
  }

  .case span {
    position: absolute;
    bottom: 0;
    left: 8px;
    color: #FF4040;
  }

  .case img {
    width: 100%;
    height: 100%;
  } // 显示图片
  .displayPicture li {
    list-style: none;
  }

  .displayPicture li img {
    width: 100%;
  }

  .title {
    color: #409eff;
    font-weight: 700;
  }

  .limitOneLine {
    // white-space:nowrap;
    // overflow:hidden;
    // text-overflow:ellipsis;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
  }

  .weui-dialog {
    width: 90%;
    max-width: 100%;
    top: 44%;
  }

  .vux-x-dialog-absolute .weui-dialog {
    position: fixed !important;
  }

</style>
