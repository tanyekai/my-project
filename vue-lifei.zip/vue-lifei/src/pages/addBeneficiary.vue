<template>
  <div>
    <group gutter='0%' style='padding:10px'>
      <cell title="用药人信息" style='color:#3385ff;font-size:18px'>
        <svg class="icon" slot='icon' style='color:#409eff'>
                <use xlink:href="#icon-huanzhe1"></use>
              </svg>
      </cell>
      <p class='remarks'>完善您的个人信息，有助于我们为您提供更好的会员服务</p>
      <!-- 姓名 -->
      <x-input v-model='name' text-align='right' placeholder-align='right' placeholder="请输入姓名">
        <span slot='label' style='color:red'>* </span>
        <span slot='label'>姓名</span>
      </x-input>
      <!-- 身份证号码 -->
      <x-input title="身份证" v-model='idNum' text-align='right' placeholder-align='right' placeholder="请输入身份证号码" :min="18" :max="18"></x-input>
      <!-- 手机 -->
      <x-input title="手机" v-model='mobile' text-align='right' placeholder-align='right' placeholder="请输入手机号" keyboard="number"></x-input>
      <!-- 医保卡号 -->
      <x-input title="医保卡号" v-model='medicalCareCard' text-align='right' placeholder-align='right' placeholder="请输入医保卡号"></x-input>
      <!-- 身高 -->
      <x-input title="身高" v-model='height' text-align='right' placeholder-align='right' placeholder="请输入患者身高"></x-input>
      <!-- 体重 -->
      <x-input title="体重" v-model='weight' text-align='right' placeholder-align='right' placeholder="请输入患者体重"></x-input>
      <!-- 与持卡人关系 -->
      <cell title='与持卡人关系' v-model='relation' @click.native='show=true' is-link></cell>
      <actionsheet v-model="show" :menus="dictCode" theme="android" @on-click-menu="clickList"></actionsheet>
      <!-- 备注 -->
      <x-textarea title='备注' v-model='remark' style="display:block" placeholder='请填写备注信息'></x-textarea>
    </group>
    <p class='remarks' style='color:#f4833c;font-size:14px'>会员购药时用药人姓名需与处方姓名一致，用药人信息一旦填写，无法修改，请谨慎填写。</p>
    <!-- 注册协议 -->
    <div class="agreement">
      <p>
        <a href="javascript:;" @click="purchaseOfDrug()">《代付药款授权协议》</a>
      </p>
      <a href="javascript:;" @click="crossSection()">《划款指示通知书》</a>
      <div v-show="readProtocol" @click="setReadProtocol()" style="float:right;">
        <span style="float: right;margin-left: -11px">已同意</span>
        <svg class="icon" slot='icon' style="width:24px;margin-top:2px;">
                <use xlink:href="#icon-duihaocheckmark17"></use>
              </svg>
      </div>
      <div v-show="unreadProtocol" @click="setUnreadProtocol()" style="float:right;">
        <span style="float: right;margin-left: -10px">请勾选</span>
        <svg class="icon" slot='icon' style="width:20px;margin-top:2px;">
                <use xlink:href="#icon-yuancircle46"></use>
              </svg>
      </div>
    </div>
    <!-- 保存 -->
    <div style='padding:0 10px'>
      <XButton style='margin-top:10%;margin-bottom:20%;background-color: #409eff;color:#fff;' @click.native='save'>保存</XButton>
    </div>
    <!-- 代付药款授权协议 -->
    <div class="agreementShow" v-show="purchaseOfDrugAgreement">
      <div class="registrationAgreement">
        <p style="text-align:center;margin:10px 0;">
          <span style="font-size:16px !important;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666"><b>代付药款授权协议</b></span>
        </p>
        <p style="text-align:justify;text-justify:inter-ideograph;text-indent:42px">
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">本代付药款授权协议以下简称“本协议”是镁信健康微信平台（下称“微信平台”）与其会员(以下简称“您”)就您个人申请并授权上海镁信健康科技有限公司（下称“镁信健康”）为您提供代付药款服务所订立的合约。<strong><span style="text-decoration:underline;">您通过网络页面在镁信健康微信平台点击确认具体委托事项的订单，即表示您<a></a>同意接受本协议的全部约定内容以及与本协议有关的已经发布或将来可能发布的各项规则、页面展示、操作流程、公告或通知（以下统称“规则”），该等约定具体委托事项的订单构成本协议的一部分。</span></strong>
          </span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">一、在接受本协议并向镁信健康微信平台操作订单之前，请您仔细阅读本协议的全部内容<strong><span style="text-decoration:underline;">（特别是以粗体下划线标注的内容）</span></strong>。如果您不同意本协议的任意内容，或者无法准确理解该条款的含义，请不要进行任何操作。</span>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">二、在通过下单键指令授权镁信健康代为处理具体委托事项的同时，您同意并委托授权镁信健康微信平台将您提供的与委托事项相关的个人信息提供给包括药品零售企业在内的第三方合作机构，以便该等第三方合作机构向您销售及配送药品。</span></span></strong>
        </p>
        <p style="text-indent:42px">
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">您能否最终完成购买药品，应以您和第三方合作机构之间的交易情况为准。</span></span></strong>
        </p>
        <p style="margin-bottom: 10px;background: white">
          <strong><span style="text-decoration:underline;"><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">三、 为使上述药品购销关系的药款顺利与该等第三方合作机构达成结算，在通过下单键指令授权镁信健康代为处理具体委托事项的同时，您同意并授权镁信微信平台指定的银行或第三方支付机构将您在指定账户（包括银行、支付宝、微信账户）中与委托事项相关的款项，划付至镁信健康指定的收款账户，并同时授权镁信健康将与委托事项相关的款项划付至第三方合作机构收款账户，以帮助您完成药款支付。</span></span></strong>
        </p>
        <p style="margin-bottom: 10px;text-indent: 42px;background: white">
          <strong><span style="text-decoration:underline;"><span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">您确认并同意点击下单键指令构成用户不可撤销的授权指示，视为委托授权购药事宜完成，镁信微信平台依照该指示进行的操作行为及其结果不承担任何责任。</span></span></strong>
        </p>
        <p style="margin-bottom: 10px;text-indent: 42px;background: white">
          <a><strong><span style="text-decoration:underline;"><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">无论基于何种原因导致用户要求退款，均由您与第三方合作机构进行协商处理，镁信微信平台不对此承担任何责任。具体退款金额由您与第三方合作机构协商确定，镁信健康微信平台不介入您和第三方合作机构的任何退款纠纷或承担任何责任。</span></span></strong></a>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">四、本协议中根据前述目的、方式被镁信健康使用或向第三方提供的个人信息，包括但不限于：</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">1</span><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">、您的身份信息，包括但不限于姓名/名称、证件号码、证件类型、住所地/收货地址、电话/手机；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">2</span><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">、相关用药者信息，包括但不限于姓名/名称、证件号码、证件类型、处方单据、病理报告以及其他身份信息；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">2</span><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">、您的账户信息，包括但不限于账号、交易明细及使用记录；</span>
        </p>
        <p>
          <span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">3</span><span style="font-size: 14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">、您在微信平台留存的银行卡或其他支付账户信息，包括但不限于卡号/账号、户名、开户行等相关信息；</span>
        </p>
        <p>
          <strong><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">五、对于上述向第三方披露的个人信息，镁信健康将事先采取相应的安全风险评估，并依照评估结果采取有效安全措施，以确保该等个人信息以安全的方式向第三方披露并且与该等个人信息相关的个人权益有所保障。</span></strong>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">六、在本协议期间及您作为镁信健康微信平台的会员期间，您同意本协议中的授权不可变更、撤回或撤销，但您可根据法律法规规定撤销或更改您对上述个人信息使用目的、方式、范围的授权。</span></span></strong>
        </p>
        <p>
          <strong><span style="text-decoration:underline;"><span style="font-size:14px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#666666">七、您同意，因履行本协议发生纠纷的，任何一方应向上海徐汇区人民法院提起诉讼。</span></span></strong>
        </p>
        <p>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p>
          <br/>
        </p>
        <div style="width: 100%;height: 70px;"></div>
        <div class="close" @click="purchaseOfDrug()">
          <a href="javascript:;">我知道了</a>
        </div>
      </div>
    </div>
    <!-- 划款指示通知书 -->
    <div class="agreementShow" v-show="noticeOfPayment" style="padding-bottom:80px;">
      <div class="registrationAgreement">
        <p style="text-align:center;margin:10px 0;">
          <span style="font-size:16px !important;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">划款指示通知书</span>
        </p>
        <p>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">经通过本人在镁信健康微信平台的会员账户每次下单确认代付药款的具体需求，本人对以下事项予以确认与同意：</span>
        </p>
        <p style="text-indent: 28px">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">本人确认，通过本人账户向镁信健康微信平台传达用药需求并申请代为支付购药款，并由本人享受镁信健康微信平台提供的会员服务。</span>
        </p>
        <p style="text-indent: 28px">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">本人确认，镁信健康微信平台处理本人上述申请、为本人提供会员服务系基于本人与镁信健康在其微信平台在线以电子合同的形式达成的《镁信健康平台服务协议》和《代付药款授权协议》等协议（具体名称以镁信健康微信平台最终实际生成的协议名称为准）， 且本人同意受前述电子合同所有条款的约束。</span>
        </p>
        <p style="text-indent: 28px">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">根据本人签署的上述协议，本人同意，在本人与药品零售企业达成的药品购销关系前提下，由委托人镁信健康代本人提供药款结算服务。故，本人特此确认、指示与通知镁信健康微信平台，本人根据具体代付申请及《代付药款授权协议》向镁信健康微信平台支付的款项，应由镁信健康代本人与相关药品零售企业进行药款结算。</span>
        </p>
        <p style="text-indent: 28px">
          <span style=";font-family: &#39;微软雅黑&#39;,&#39;sans-serif&#39;">本人确认并同意在镁信健康微信平台预付药款，并享受镁信健康微信平台所提供的代会员支付药款的服务。本指示通知书一经做出即不可撤销，并由本人承担一切相关法律责任。</span>
        </p>
        <p>
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p>
          <a></a><span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p style="text-align:right">
          <span style=";font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;">&nbsp;</span>
        </p>
        <p>
          <br/>
        </p>
        <div style="width: 100%;height: 70px;"></div>
        <div class="close" @click="crossSection()">
          <a href="javascript:;">我知道了</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Api_patient from '@/api/patient';
  import Api_member from '@/api/member';
  import {
    TransferDom,
    Popup,
    Group,
    Cell,
    XButton,
    XSwitch,
    Toast,
    XAddress,
    XInput,
    PopupRadio,
    AlertModule,
    Selector,
    Actionsheet,
    XTextarea
  } from 'vux'
  export default {
    directives: {
      TransferDom
    },
    components: {
      Popup,
      Group,
      Cell,
      XSwitch,
      Toast,
      XAddress,
      XButton,
      XInput,
      PopupRadio,
      AlertModule,
      Selector,
      Actionsheet,
      XTextarea
    },
    data() {
      return {
        // ==================
        name: '',
        mobile: '',
        idNum: '',
        medicalCareCard: '',
        height: '',
        weight: '',
        relation: '',
        relationKey: '',
        remark: '',
        // ==================
        show: false,
        dictCode: '',
        readProtocol: false,
        unreadProtocol: true,
        noticeOfPayment: false,
        purchaseOfDrugAgreement: false,
      }
    },
    methods: {
      save() {
        if (!this.name) {
          this.$vux.toast.text("请输入姓名");
        } else if (!this.readProtocol) {
          this.$vux.toast.text("请阅读协议");
        } else {
          this.add();
        }
      },
      add() {
        new Promise((resolve, reject) => {
          Api_patient.add(
              this.name,
              this.idNum,
              this.idCardType,
              this.medicalCareCard,
              this.mobile,
              this.relationKey,
              this.remark,
              this.height,
              this.weight
            )
            .then(response => {
              if (sessionStorage.getItem('orderSource') == 'deliveryToHome') {
                sessionStorage.removeItem("orderSource");
                this.showPlugin('/deliveryToHome');
              } else {
                this.showPlugin('/beneficiaryInfo');
              }
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
      // 带出姓名和身份证号
      info() {
        new Promise((resolve, reject) => {
          Api_member.info()
            .then(response => {
              this.name = response.result.name;
              this.idNum = response.result.idNum;
              this.mobile = response.result.phoneNo;
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
      // 数据字典查询
      dictCodeQuery() {
        new Promise((resolve, reject) => {
          Api_patient.dictCodeQuery()
            .then(response => {
              this.dictCode = response.result
            })
            .catch(error => {
              this.$vux.toast.text(error);
              reject(error);
            });
        });
      },
      //  添加用药人成功/失败提示
      showPlugin(path) {
        let self = this;
        this.$vux.alert.show({
          title: "恭喜！",
          content: "添加成功！",
          onShow() {},
          onHide() {
            self.$router.push(path);
          }
        })
      },
      clickList(key) {
        this.relation = this.dictCode[key];
        this.relationKey = key;
      },
      // 划款指示通知书
      crossSection() {
        if (this.noticeOfPayment) {
          this.noticeOfPayment = false;
        } else {
          this.noticeOfPayment = true;
        }
      },
      // 购买药品委托授权协议
      purchaseOfDrug() {
        if (this.purchaseOfDrugAgreement) {
          this.purchaseOfDrugAgreement = false;
        } else {
          this.purchaseOfDrugAgreement = true;
        }
      },
      // 是否阅读协议
      setReadProtocol() {
        if (this.readProtocol) {
          this.readProtocol = false;
          this.unreadProtocol = true;
        }
      },
      setUnreadProtocol() {
        if (this.unreadProtocol) {
          this.unreadProtocol = false;
          this.readProtocol = true;
        }
      }
    },
    mounted() {
      this.info();
      this.dictCodeQuery();
    }
  }
</script>

<style lang="less" scoped>
  @import '~vux/src/styles/close.less';
  /* 协议弹窗 */
  .agreement {
    padding: 10px 4%;
  }
  .agreement a {
    color: #007aff;
    margin-left: 4px;
  }
  .agreementShow {
    width: 100%;
    height: auto;
    background-color: #ffffff;
    z-index: 999;
    position: absolute;
    top: 0;
    left: 0;
  }
  .registrationAgreement {
    width: 96%;
    padding: 0 2%;
  }
  .close {
    height: 50px;
    width: 80%;
    margin: 0 auto;
    background-color: #007aff;
    border-radius: 25px;
    position: fixed;
    bottom: 20px;
    left: 10%;
    line-height: 50px;
    text-align: center;
    font-size: 20px;
  }
  .close a {
    color: #ffffff;
  } //  .agreementShow p{
  //   text-align: justify;
  //   font-size: 12px ;
  // }
  .agreementShow p span {
    font-size: 12px !important;
  }
  .remarks {
    font-size: 12px;
    padding-left: 4%;
    background-color: #f2f7f8;
    color: #a7a7a7;
  }
</style>
