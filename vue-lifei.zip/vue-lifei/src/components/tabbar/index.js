import Tabbar from './tabbar'
import TabbarItem from './tabbar-item'

export {
  Tabbar,
  TabbarItem
}
