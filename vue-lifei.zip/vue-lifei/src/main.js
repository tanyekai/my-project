import objectAssign from 'object-assign'

import Vue from 'vue'

import App from './App'

import Vuex from 'vuex'
import vuexI18n from 'vuex-i18n'
import VueRouter from 'vue-router'
import {
  sync
} from 'vuex-router-sync'

import './assets/iconfont/iconfont' //引入iconfont.js


// 高德地图 引入vue-amap
import AMap from 'vue-amap';
Vue.use(AMap);
// 初始化vue-amap
AMap.initAMapApiLoader({
  // 申请的高德key
  key: '8bff79003b55c13bcfcbec92f3b5b115',
  // 插件集合
  plugin: ['']
});


Vue.use(VueRouter)
Vue.use(Vuex)

require('es6-promise').polyfill()

/** i18n **/
let store = new Vuex.Store({
  modules: {
    i18n: vuexI18n.store
  }
})

Vue.use(vuexI18n.plugin, store)

const vuxLocales = require('json-loader!yaml-loader!./locales/all.yml')
const componentsLocales = require('json-loader!yaml-loader!./locales/components.yml')

const finalLocales = {
  'en': objectAssign(vuxLocales['en'], componentsLocales['en']),
  'zh-CN': objectAssign(vuxLocales['zh-CN'], componentsLocales['zh-CN'])
}

for (let i in finalLocales) {
  Vue.i18n.add(i, finalLocales[i])
}

import {
  DatetimePlugin,
  CloseDialogsPlugin,
  ConfigPlugin,
  BusPlugin,
  LocalePlugin,
  DevicePlugin,
  ToastPlugin,
  AlertPlugin,
  ConfirmPlugin,
  LoadingPlugin,
  WechatPlugin,
  AjaxPlugin,
  AppPlugin
} from 'vux'

Vue.use(LocalePlugin)
const nowLocale = Vue.locale.get()
if (/zh/.test(nowLocale)) {
  Vue.i18n.set('zh-CN')
} else {
  Vue.i18n.set('en')
}

store.registerModule('vux', {
  state: {
    demoScrollTop: 0,
    isLoading: false,
    direction: 'forward'
  },
  mutations: {
    updateDemoPosition(state, payload) {
      state.demoScrollTop = payload.top
    },
    updateLoadingStatus(state, payload) {
      state.isLoading = payload.isLoading
    },
    updateDirection(state, payload) {
      state.direction = payload.direction
    }
  },
  actions: {
    updateDemoPosition({
      commit
    }, top) {
      commit({
        type: 'updateDemoPosition',
        top: top
      })
    }
  }
})

// global VUX config
Vue.use(ConfigPlugin, {
  $layout: 'VIEW_BOX' // global config for VUX, since v2.5.12
})

// plugins
Vue.use(DevicePlugin)
Vue.use(ToastPlugin)
Vue.use(AlertPlugin)
Vue.use(ConfirmPlugin)
Vue.use(LoadingPlugin)
Vue.use(WechatPlugin)
Vue.use(AjaxPlugin)
Vue.use(BusPlugin)
Vue.use(DatetimePlugin)

// console.log(Vue.wechat.config)
// console.log(Vue.http)

// test
if (process.env.platform === 'app') {
  Vue.use(AppPlugin, store)
}

const wx = Vue.wechat
const http = Vue.http

// =========================================================
// if (process.env.NODE_ENV === 'production') {

// } else {

// }
// =========================================================

/**
 * -------------------------- 微信分享 ----------------------
 * 请不要直接复制下面代码
 */

if (process.env.NODE_ENV === 'production') {

  wx.ready(() => {
    wx.onMenuShareAppMessage({
      title: 'VUX', // 分享标题
      desc: '基于 WeUI 和 Vue 的移动端 UI 组件库',
      link: 'https://vux.li?x-page=wechat_share_message',
      imgUrl: 'https://static.vux.li/logo_520.png'
    })

    wx.onMenuShareTimeline({
      title: 'VUX', // 分享标题
      desc: '基于 WeUI 和 Vue 的移动端 UI 组件库',
      link: 'https://vux.li?x-page=wechat_share_timeline',
      imgUrl: 'https://static.vux.li/logo_520.png'
    })

  })

  const permissions = JSON.stringify(['onMenuShareTimeline', 'onMenuShareAppMessage', 'chooseWXPay'])
  const url = document.location.href
  http.post('https://vux.li/jssdk?url=' + encodeURIComponent(url.split('#')[0]) + '&jsApiList=' + permissions).then(res => {
    wx.config(res.data.data)
  })
}

const FastClick = require('fastclick')
FastClick.attach(document.body)

// TOKEN
const TOKEN = sessionStorage.getItem('TOKEN');

// The following line will be replaced with by vux-loader with routes in ./demo_list.json

// router
const routes = [{
    path: '/',
    redirect: '/myAccount'
  },
  {
    path: '/myAccount', // 我的账户
    component: function (resolve) {
      require(['./pages/myAccount.vue'], resolve)
    }
  }, {
    path: '/myOrder', // 我的订单
    component: function (resolve) {
      require(['./pages/myOrder.vue'], resolve)
    }
  },
  {
    path: '/buyVipCard', // 购买会员卡
    component: function (resolve) {
      require(['./pages/buyVipCard.vue'], resolve)
    }
  }, {
    path: '/bankCardVerified', // 实名认证
    component: function (resolve) {
      require(['./pages/bankCardVerified.vue'], resolve)
    }
  }, {
    path: '/bankCardVerifiedInfo', // 实名认证-银行卡信息
    component: function (resolve) {
      require(['./pages/bankCardVerifiedInfo.vue'], resolve)
    }
  },
  {
    path: '/myBills', // 我的账单
    component: function (resolve) {
      require(['./pages/myBills.vue'], resolve)
    }
  }, {
    path: '/addAddress', // 新增地址
    component: function (resolve) {
      require(['./pages/addAddress.vue'], resolve)
    }
  }, {
    path: '/editAddress', // 编辑地址
    component: function (resolve) {
      require(['./pages/editAddress.vue'], resolve)
    }
  }, {
    path: '/pharmacyBuyMedicine', // 药店购药
    component: function (resolve) {
      require(['./pages/pharmacyBuyMedicine.vue'], resolve)
    }
  }, {
    path: '/deliveryToHome', // 送药到家
    component: function (resolve) {
      require(['./pages/deliveryToHome.vue'], resolve)
    }
  }, {
    path: '/address', // 收货人地址
    component: function (resolve) {
      require(['./pages/address.vue'], resolve)
    }
  }, {
    path: '/choosePharmacy', // 选择药店
    component: function (resolve) {
      require(['./pages/choosePharmacy.vue'], resolve)
    }
  },
  {
    path: '/mobileBinding', // 用户手机绑定
    component: function (resolve) {
      require(['./pages/mobileBinding.vue'], resolve)
    }
  },
  {
    path: '/addBeneficiary', // 添加用药人
    component: function (resolve) {
      require(['./pages/addBeneficiary.vue'], resolve)
    }
  },
  {
    path: '/beneficiaryInfo', // 用药人信息
    component: function (resolve) {
      require(['./pages/beneficiaryInfo.vue'], resolve)
    }
  },
  {
    path: '/vipInfo', // 会员信息
    component: function (resolve) {
      require(['./pages/vipInfo.vue'], resolve)
    }
  },
  {
    path: '/addMember', // 添加会员信息
    component: function (resolve) {
      require(['./pages/addMember.vue'], resolve)
    }
  },
  {
    path: '/error', // 报错信息
    component: function (resolve) {
      require(['./pages/error.vue'], resolve)
    }
  },
  {
    path: '/mock', // 模拟登录
    component: function (resolve) {
      require(['./pages/mock.vue'], resolve)
    }
  },
  {
    path: '/myBankCard', // 我的银行卡
    component: function (resolve) {
      require(['./pages/myBankCard.vue'], resolve)
    }
  },
  {
    path: '/myBankCardInfo', // 我的银行卡信息
    component: function (resolve) {
      require(['./pages/myBankCardInfo.vue'], resolve)
    }
  },
  {
    path: '/drugCatalogue', // 药店搜索
    component: function (resolve) {
      require(['./pages/drugCatalogue.vue'], resolve)
    }
  },
  {
    path: '/financialStaging', // 金融分期
    component: function (resolve) {
      require(['./pages/financialStaging.vue'], resolve)
    }
  },
  {
    path: '/orderDetails', // 订单详情
    component: function (resolve) {
      require(['./pages/orderDetails.vue'], resolve)
    }
  },
  {
    path: '/orderDetailsPharmacies', // 订单详情(到店购药)
    component: function (resolve) {
      require(['./pages/orderDetailsPharmacies.vue'], resolve)
    }
  },
  {
    path: '/orderWXPay', // 订单微信支付
    component: function (resolve) {
      require(['./pages/orderWXPay.vue'], resolve)
    }
  },
  {
    path: '/orderQrPay', // 订单扫码支付
    component: function (resolve) {
      require(['./pages/orderQrPay.vue'], resolve)
    }
  },
  {
    path: '/orderWXPayThird', // 订单第三方微信支付
    component: function (resolve) {
      require(['./pages/orderWXPayThird.vue'], resolve)
    }
  },
  {
    path: '/orderBankPay', // 订单银行卡支付
    component: function (resolve) {
      require(['./pages/orderBankPay.vue'], resolve)
    }
  },
  {
    path: '/paySuccess', // 支付成功页面
    component: function (resolve) {
      require(['./pages/paySuccess.vue'], resolve)
    }
  },
  {
    path: '/payVipSuccess', // 购买会员成功页面
    component: function (resolve) {
      require(['./pages/payVipSuccess.vue'], resolve)
    }
  },
  {
    path: '/activateVip', // 激活会员
    component: function (resolve) {
      require(['./pages/activateVip.vue'], resolve)
    }
  },
  {
    path: '/registrationAgreement', // 注册协议
    component: function (resolve) {
      require(['./pages/registrationAgreement.vue'], resolve)
    }
  },
  {
    path: '/myQrCode', // 我的二维码
    component: function (resolve) {
      require(['./pages/myQrCode.vue'], resolve)
    }
  },
  {
    path: '/memberService', // 臻享服务
    component: function (resolve) {
      require(['./pages/memberService.vue'], resolve)
    }
  }
]

const router = new VueRouter({
  routes
})

Vue.use(CloseDialogsPlugin, router)

sync(store, router)

// simple history management
const history = window.sessionStorage
history.clear()
let historyCount = history.getItem('count') * 1 || 0
history.setItem('/', 0)

router.beforeEach(function (to, from, next) {
  store.commit('updateLoadingStatus', {
    isLoading: true
  })

  const toIndex = history.getItem(to.path)
  const fromIndex = history.getItem(from.path)

  if (toIndex) {
    if (!fromIndex || parseInt(toIndex, 10) > parseInt(fromIndex, 10) || (toIndex === '0' && fromIndex === '0')) {
      store.commit('updateDirection', {
        direction: 'forward'
      })
    } else {
      store.commit('updateDirection', {
        direction: 'reverse'
      })
    }
  } else {
    ++historyCount
    history.setItem('count', historyCount)
    to.path !== '/' && history.setItem(to.path, historyCount)
    store.commit('updateDirection', {
      direction: 'forward'
    })
  }


  if (/\/http/.test(to.path)) {
    let url = to.path.split('http')[1]
    window.location.href = `http${url}`
  } else {
    next()
  }


})

router.afterEach(function (to) {
  store.commit('updateLoadingStatus', {
    isLoading: false
  })
  if (process.env.NODE_ENV === 'production') {
    ga && ga('set', 'page', to.fullPath)
    ga && ga('send', 'pageview')
  }
})

new Vue({
  store,
  router,
  render: h => h(App)
}).$mount('#app')
