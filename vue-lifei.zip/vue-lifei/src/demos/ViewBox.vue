<template>
  <div>
    <p v-for="i in 100">{{i}}</p>
  </div>
</template>

