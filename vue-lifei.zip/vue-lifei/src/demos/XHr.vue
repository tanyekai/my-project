<template>
  <div>
    <x-hr></x-hr>
  </div>
</template>

<script>
import { XHr } from 'vux'

export default {
  components: {
    XHr
  }
}
</script>