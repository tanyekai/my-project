<template>
  <div>
  </div>
</template>

<script>
export default {
  created () {
    console.log(this.$wechat)
  }
}
</script>
