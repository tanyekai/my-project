<template>
  <div>querystring</div>
</template>

<script>
import { querystring } from 'vux'
console.log(querystring.parse())
export default {
  filters: {
    querystring
  }
}
</script>