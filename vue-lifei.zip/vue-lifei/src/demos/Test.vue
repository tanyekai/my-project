<template>
	<div>
		test template
	</div>
</template>

<script>
import { Group, Cell } from 'vux'

export default {
  components: {
    Group,
    Cell
  },
  data () {
    return {
      msg: 'test'
    }
  }
}
</script>