<template>
  <div style="text-align:center;">{{ $t('貌似示例不存在')}}</div>
</template>

<i18n>
貌似示例不存在:
  en: Sorry, demo doesn't exist
</i18n>