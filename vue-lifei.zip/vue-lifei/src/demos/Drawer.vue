<template>
  <div style="text-align:center;">
    代码位于 <a href="https://github.com/airyland/vux/blob/v2/src/App.vue">App.vue</a>
  </div>
</template>
