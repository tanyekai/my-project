import fetch from '../libs/fetch';

export default {

  //  添加用药人
  add(name, idNum, idCardType, medicalCareCard, mobile, relation, remark, height, weight) {
    const data = {
      name,
      idNum,
      idCardType,
      medicalCareCard,
      mobile,
      relation,
      remark,
      height,
      weight
    };
    return fetch({
      url: '/api-member/api/v1/patient/add',
      method: 'POST',
      data
    });
  },

  // 查询用药人
  queryPatient() {
    return fetch({
      url: '/api-member/api/v1/patient/query',
      method: 'GET',
    });
  },
  
  // 数据字典查询用药人与患者关系
  dictCodeQuery() {
    return fetch({
      url: '/api-config/v1/dict/value/dictCode?dictCode=USER_PATIENT_RELATION',
      method: 'GET'
    });
  }
}
