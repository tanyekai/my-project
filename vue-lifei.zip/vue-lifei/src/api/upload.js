import fetch from '../libs/fetch';

export default {

  //  图片上传
  upload(param, datumCode, userType) {
    return fetch({
      url: '/zuul/api-data/api/v1/upload/userDatumImage/savePrescription?userType=' + userType + '&datumCode=' + datumCode,
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
        'dataType': 'file',
        // 'X-Fast-UserId': '1'
      },
      data: param
    });
  },

  //  图片删除
  delete(imageId) {
    return fetch({
      url: '/api-data/api/image/delete?imageId=' + imageId,
      method: 'GET',
    });
  },


}
