import fetch from '../libs/fetch';

export default {

  //  银行卡绑定，获取短信验证码
  bankBind(userName, idCardNo, mobile, bankName, bankCard) {
    const data = {
      userName,
      idCardNo,
      mobile,
      bankName,
      bankCard
    };
    return fetch({
      url: '/api-trans/api/v1/userAccount/bankBind',
      method: 'POST',
      data
    });
  },

  //  短信验证
  checkBindSms(validateCode, bankCard, bankName, bankCode) {
    const data = {
      validateCode,
      bankCard,
      bankName,
      bankCode
    };
    return fetch({
      url: '/api-trans/api/v1/userAccount/checkBindSms',
      method: 'POST',
      data
    });
  },

  //  银行卡信息查询
  bankBindQuery() {
    return fetch({
      url: '/api-trans/api/v1/userAccount/bankBindQuery',
      method: 'POST',
    });
  },

  // 检查是否绑卡
  checkBankBind() {
    return fetch({
      url: '/api-trans/api/v1/userAccount/checkBankBind',
      method: 'POST',
    });
  },

  //  解绑银行卡
  unbindCard(bankCard) {
    const data = {
      bankCard
    };
    return fetch({
      url: '/api-trans/api/v1/userAccount/unbindCard',
      method: 'POST',
      data
    });
  },

  //  设为默认
  setDefault(bankCard) {
    const data = {
      bankCard
    };
    return fetch({
      url: '/api-trans/api/v1/userAccount/setBankDefault',
      method: 'POST',
      data
    });
  },

  // 银行卡支付
  bankPay(bizType, transSource, orderNo, orderType, bankCard) {
    const data = {
      bizType,
      transSource,
      orderNo,
      orderType,
      bankCard
    };
    return fetch({
      url: '/api-trans/api/v1/bizTrans/bankPay',
      method: 'POST',
      data
    });
  },



}
