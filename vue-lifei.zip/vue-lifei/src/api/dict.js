import fetch from '../libs/fetch';

export default {

  // 订单状态码
  dictCodeQuery(dictCode) {
    return fetch({
      url: '/api-config/v1/dict/value/dictCode?dictCode=' + dictCode,
      method: 'GET'
    });
  },
}
