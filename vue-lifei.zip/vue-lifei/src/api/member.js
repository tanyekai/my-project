import fetch from '../libs/fetch';

export default {

  // 短信验证码获取
  smsCode(phoneNo, captcha) {
    const data = {
      phoneNo,
      captcha
    };
    return fetch({
      url: '/api/v1/user/register/sms',
      method: 'POST',
      data
    });
  },

  // 验证码校验
  register(phoneNo, smsCode) {
    const data = {
      phoneNo,
      smsCode
    };
    return fetch({
      url: '/api/v1/user/register/auth',
      method: 'POST',
      data
    });
  },

  // 获取会员手机号
  profile() {
    return fetch({
      url: '/api-member/api/v1/user/profile',
      method: 'GET',
    });
  },


  // 更新会员信息
  update(name, idNum) {
    const data = {
      name,
      idNum
    };
    return fetch({
      url: '/api-member/api/v1/user/update',
      method: 'POST',
      data
    });
  },


  // 会员二维码展示
  qrImage() {
    return fetch({
      url: '/api-member/api/v1/user/qr/image',
      method: 'GET',
    });
  },

  // 会员卡展示,健康卡,关爱卡
  list() {
    return fetch({
      url: '/api-product/api/v1/vip/card/issued/list',
      method: 'POST',
    });
  },

  // 扫码激活会员
  signature(url) {
    const data = {
      url
    };
    return fetch({
      url: '/api-wechat/v1/jsapi/signature',
      method: 'POST',
      data
    });
  },

  // 判断是否是会员
  isVip() {
    return fetch({
      url: '/api-member/api/v1/user/isVip',
      method: 'GET',
    });
  },

  // 激活会员，通过扫描到的卡号获得vipCardProductId
  cardNo(cardNo) {
    return fetch({
      url: '/api-member/api/v1/vip/card/issued/profile/cardNo?cardNo=' + cardNo,
      method: 'GET',
    });
  },

  // 获取user的姓名和身份证
  info() {
    return fetch({
      url: '/api-member/api/v1/user/authname/info',
      method: 'GET'
    })
  }

}
