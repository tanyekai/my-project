import fetch from '../libs/fetch';

export default {

  //  模拟登录
  mock(openId, projectId) {
    const data = {
      openId,
      projectId
    };
    return fetch({
      url: '/api/v1/mock/login',
      method: 'POST',
      data
    });
  },

  //  判断是否为微信端
  check(locationUrl) {
    const data = {
      locationUrl
    };
    return fetch({
      url: '/api/v1/check',
      method: 'POST',
      data
    });
  },

  // 头像显示
  profile() {
    return fetch({
      url: '/api-wechat/v1/user/profile',
      method: 'GET',
    });
  },

  // 判断是否已经登录
  registed() {
    return fetch({
      url: '/api/v1/user/registed',
      method: 'POST',
    });
  },

  
}
