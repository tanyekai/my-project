import fetch from '../libs/fetch';

export default {

  //  微信支付
  wxPay(orderType, vipCardProductId, cardNo) {
    const data = {
      orderType,
      vipCardProductId,
      cardNo
    };
    return fetch({
      url: '/api-trans/api/v1/bizTrans/wxPay4Member',
      method: 'POST',
      data
    });
  },

  //  会员支付成功返回交易流水
  callBack(orderNo) {
    const data = {
      orderNo
    };
    return fetch({
      url: '/api-trans/api/v1/bizTrans/wxPay4MemberCallback',
      method: 'POST',
      data
    });
  },

  //  订单微信支付
  orderWXPay(orderNo, bizType, orderType) {
    const data = {
      orderNo,
      bizType,
      orderType
    };
    return fetch({
      url: '/api-trans/api/v1/bizTrans/wxPay',
      method: 'POST',
      data
    });
  },

  // 订单微信支付成功状态校验
  wxPayOrderQuery(orderNo) {
    return fetch({
      url: '/api-trans/api/v1/bizTrans/wxPayOrderQuery?orderNo=' + orderNo,
      method: 'POST',
    });
  },

    //  订单二维码支付
    wxPayQr(bizType, orderNo,  orderType) {
      const data = {
        bizType,
        orderNo,
        orderType
      };
      return fetch({
        url: '/api-trans/api/v1/bizTrans/wxPayQr',
        method: 'POST',
        data
      });
    },

    //  订单第三方微信支付
    wxPayThird(params) {
      return fetch({
        url: '/api-trans/api/callback/v1/bizTrans/third/wxPayThird' + params,
        method: 'GET',
      });
    },
}
