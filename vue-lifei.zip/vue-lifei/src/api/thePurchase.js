import fetch from '../libs/fetch';

export default {
  // 中国省市区
  chinaQuery() {
    return fetch({
      url: '/api-config/v1/china',
      method: 'GET',
    })
  },
  // 中国省市区查询
  chinaSearchQuery() {
    return fetch({
      url: '/api-config/v1/china/search',
      method: 'GET',
    })
  },

  // 药品查药店
  drugstoreInquiries(name) {
    return fetch({
      url: '/api-partner/api/v1/count?name=' + name,
      method: 'GET'
    })
  },

  //已搜索药店展示
  drugstoreDisplay(DrugId) {
    const data = {
      DrugId
    };
    return fetch({
      url: '/api-partner/api/v1/pharmacy/pharmacyQuery',
      method: 'POST',
      data
    });
  },
  // 药店列表展示（到店购药）
  drugstoresList(longitude,latitude,pageSize,page) {
    const data = {
      longitude,
      latitude,
      pageSize,
      page
    };
    return fetch({
      url: '/api-partner/api/v1/wechat/pharmacy/latitudeAndlongitude',
      method: 'POST',
      data
    });
  },

  //地址查药店
  addressDrugstore(provinceCode, cityCode, districtCode) {
    provinceCode = provinceCode == "PS0001" ? "" : provinceCode;
    cityCode = cityCode == "CS0001" ? "" : cityCode;
    districtCode = districtCode == "AS0001" ? "" : districtCode;
    const data = {
      provinceCode,
      cityCode,
      districtCode
    };
    return fetch({
      url: '/api-partner/api/v1/pharmacy/pharmacyQuery',
      method: 'POST',
      data
    });
  },
  //微信地图api调取
  WeChatMap(url) {
    const data = {
      url
    };
    return fetch({
      url: '/api-wechat/v1/jsapi/signature',
      method: 'POST',
      data
    });
  },

  //增加收货地址或设为默认地址
  newAddress(receiver, mobile, provinceCode, cityCode, districtCode, fullAddress, isDefault, userId) {
    const data = {
      receiver,
      mobile,
      provinceCode,
      cityCode,
      districtCode,
      fullAddress,
      isDefault,
      userId
    };
    return fetch({
      url: '/api-member/api/v1/address/add',
      method: 'POST',
      data,
    });
  },

  //地址管理
  // addressManagement(id) {
  //   return fetch({
  //     url: '/api-member/api/v1/address/query',
  //     method: 'GET',
  //   });
  // },
  //地址删除
  deleteAddress(id) {
    return fetch({
      url: '/api-member/api/v1/address/delete?id=' + id,
      method: 'GET',
    });
  },
  // 地址编辑
  editAddress(id, receiver, mobile, provinceCode, cityCode, districtCode, fullAddress, isDefault) {
    const data = {
      id,
      receiver,
      mobile,
      provinceCode,
      cityCode,
      districtCode,
      fullAddress,
      isDefault,
    };
    return fetch({
      url: '/api-member/api/v1/address/update',
      method: 'POST',
      data,
    });
  },
    //送药到家订单状态
    orderStatus(status){
        const data = {
            status
        };
        return fetch({
            url: '/api-trans/api/v1/homedeliveryOrder/queryOrderList',
            method: 'POST',
            data
        });
    },
   //到店购药订单状态
  shopOrderStatus(status) {
    const data = {
      status
    };
    return fetch({
      url: '/api-trans/api/v1/pharmacybuyOrder/pharmacybuyOrderListWechat',
      method: 'POST',
      data
    });
  },

    //订单详情(送药到家)
    orderDetails(orderNo){
        const data = {
            orderNo
        };
        return fetch({
            url: '/api-trans/api/v1/homedeliveryOrder/queryOrderEntity',
            method: 'POST',
            data
        });
    },
  //订单详情(药店购药)
  orderDetailsPharmacies(orderNo) {
    const data = {
      orderNo
    };
    return fetch({
      url: '/api-trans/api/v1/pharmacybuyOrder/queryOrderEntity',
      method: 'POST',
      data
    });
  },
  //订单状态码
  dictCodeQuery(dictCode) {
    return fetch({
      url: '/api-config/v1/dict/value/dictCode?dictCode=' + dictCode, 
      method: 'GET'
    });
  },
  //订单完成(送药到家)
  orderCompletion(orderNo){
    const data = {
      orderNo
    };
    return fetch({
      url: '/api-trans/api/v1/homedeliveryOrder/orderComplete',
      method: 'POST',
      data
    });
  }
}
