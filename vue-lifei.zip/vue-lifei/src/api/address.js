import fetch from '../libs/fetch';

export default {
  //  通过id查询收货人地址信息list数组
  query(id) {
    const data = {
      id
    };
    return fetch({
      url: '/api-member/api/v1/address/query',
      method: 'POST',
      data
    });
  },

  // 更新地址
  update(id, receiver, mobile, provinceCode, cityCode, districtCode, fullAddress, isDefault) {
    const data = {
      id,
      receiver,
      mobile,
      provinceCode,
      cityCode,
      districtCode,
      fullAddress,
      isDefault,
    };
    return fetch({
      url: '/api-member/api/v1/address/update',
      method: 'POST',
      data
    });
  },

  // 删除地址
  delete(id) {
    return fetch({
      url: '/api-member/api/v1/address/delete?id=' + id,
      method: 'GET',
    });
  },

}
