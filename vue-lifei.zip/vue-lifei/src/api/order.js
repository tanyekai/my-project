import fetch from '../libs/fetch';

export default {

  //  提交订单
  submitOrder(addressId, prescriptionId, expectFreightDate, remark) {
    const data = {
      addressId,
      prescriptionId,
      expectFreightDate,
      remark
    };
    return fetch({
      url: '/api-trans/api/v1/homedeliveryOrder/submitOrder',
      method: 'POST',
      data
    });
  },

  //  查询订单列表
  queryOrderList(status) {
    const data = {
      status
    };
    return fetch({
      url: '/api-trans/api/v1/homedeliveryOrder/queryOrderList',
      method: 'POST',
      data
    });
  },

  //  查询订单实体
  queryOrderEntity(orderId) {
    const data = {
      orderId
    };
    return fetch({
      url: '/api-trans/api/v1/homedeliveryOrder/queryOrderEntity',
      method: 'POST',
      data
    });
  },

}
